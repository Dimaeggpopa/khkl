import SwiftUI

enum GarageMainTab: String, CaseIterable, Identifiable {
    case home = "home"
    case warehouse = "warehouse"
    case publish = "publish"
    case dialogs = "dialogs"
    case more = "more"

    var id: String { rawValue }

    var label: String {
        switch self {
        case .home: return "Главная"
        case .warehouse: return "Мой склад"
        case .publish: return "Публикация"
        case .dialogs: return "Диалоги"
        case .more: return "Ещё"
        }
    }

    var systemImage: String {
        switch self {
        case .home: return "house.fill"
        case .warehouse: return "shippingbox.fill"
        case .publish: return "bolt.fill"
        case .dialogs: return "bubble.left.and.bubble.right.fill"
        case .more: return "ellipsis.circle.fill"
        }
    }
}

struct MainTabView: View {
    let userId: String
    let userEmail: String
    let onSignOut: () -> Void

    @StateObject private var viewModel: GarageViewModel
    @State private var currentTab: GarageMainTab = .home

    @State private var showAddOrEditModal = false
    @State private var editingItem: GarageItem? = nil
    @State private var photoHintItem: GarageItem? = nil
    @State private var editingPlatformType: PlatformType? = nil
    @State private var showQrScannerModal = false
    @State private var showCreateDialogModal = false
    @State private var showPromotionModal = false

    init(userId: String, userEmail: String, onSignOut: @escaping () -> Void) {
        self.userId = userId
        self.userEmail = userEmail
        self.onSignOut = onSignOut
        _viewModel = StateObject(wrappedValue: GarageViewModel(userId: userId))
    }

    private var unreadCount: Int {
        viewModel.dialogs.reduce(0) { $0 + Int($1.unreadCount) }
    }

    private var userInitials: String {
        let prefix = String(userEmail.prefix(2)).uppercased()
        return prefix.isEmpty ? "МГ" : prefix
    }

    private var preferredScheme: ColorScheme? {
        switch viewModel.themeMode {
        case .dark: return .dark
        case .light: return .light
        case .system: return nil
        }
    }

    var body: some View {
        ZStack {
            GarageTheme.background
                .ignoresSafeArea()

            VStack(spacing: 0) {
                GarageTopBar(
                    title: "Мой гараж",
                    unreadNotificationsCount: unreadCount,
                    userInitials: userInitials,
                    onNotificationsClick: { currentTab = .dialogs },
                    onProfileClick: { currentTab = .more }
                )

                Rectangle()
                    .fill(GarageTheme.outline.opacity(0.6))
                    .frame(height: 1)

                if let bannerMsg = viewModel.publishProgress.completedBannerMessage {
                    HStack(spacing: 8) {
                        Text(bannerMsg)
                            .font(.system(size: 12, weight: .bold))
                            .foregroundColor(GarageTheme.emeraldGreen)
                            .multilineTextAlignment(.leading)

                        Spacer()

                        Button {
                            viewModel.publishProgress.completedBannerMessage = nil
                        } label: {
                            Text("ОК")
                                .font(.system(size: 12, weight: .extrabold))
                                .foregroundColor(GarageTheme.textPrimary)
                                .padding(.horizontal, 10)
                                .padding(.vertical, 5)
                                .background(GarageTheme.cardBg)
                                .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
                        }
                        .buttonStyle(.plain)
                    }
                    .padding(.horizontal, 14)
                    .padding(.vertical, 10)
                    .background(GarageTheme.emeraldGreen.opacity(0.16))
                    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .stroke(GarageTheme.emeraldGreen.opacity(0.45), lineWidth: 1)
                    )
                    .padding(.horizontal, 16)
                    .padding(.top, 8)
                }

                // Active screen content
                Group {
                    switch currentTab {
                    case .home:
                        HomeView(
                            viewModel: viewModel,
                            onAddItem: {
                                editingItem = nil
                                showAddOrEditModal = true
                            },
                            onEditItem: { item in
                                editingItem = item
                                showAddOrEditModal = true
                            },
                            onOpenPhotoHint: { item in
                                photoHintItem = item
                            },
                            onOpenQrScanner: {
                                showQrScannerModal = true
                            },
                            onOpenPlatformSettings: { type in
                                editingPlatformType = type
                            },
                            onOpenPromotion: {
                                showPromotionModal = true
                            },
                            onNavigateToDialogs: {
                                currentTab = .dialogs
                            }
                        )
                    case .warehouse:
                        WarehouseView(
                            viewModel: viewModel,
                            onAddItem: {
                                editingItem = nil
                                showAddOrEditModal = true
                            },
                            onEditItem: { item in
                                editingItem = item
                                showAddOrEditModal = true
                            },
                            onOpenPhotoHint: { item in
                                photoHintItem = item
                            },
                            onOpenQrScanner: {
                                showQrScannerModal = true
                            }
                        )
                    case .publish:
                        PublishView(
                            viewModel: viewModel,
                            onEditItem: { item in
                                editingItem = item
                                showAddOrEditModal = true
                            },
                            onOpenPhotoHint: { item in
                                photoHintItem = item
                            },
                            onOpenPlatformSettings: { type in
                                editingPlatformType = type
                            }
                        )
                    case .dialogs:
                        DialogsView(
                            viewModel: viewModel,
                            onOpenPhotoHint: { item in
                                photoHintItem = item
                            },
                            onCreateDialog: {
                                showCreateDialogModal = true
                            }
                        )
                    case .more:
                        MoreView(
                            viewModel: viewModel,
                            userEmail: userEmail,
                            onOpenPlatformSettings: { type in
                                editingPlatformType = type
                            },
                            onOpenPhotoHint: { item in
                                photoHintItem = item
                            },
                            onSignOut: onSignOut
                        )
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)

                GarageBottomBarIOS(
                    currentTab: currentTab,
                    unreadDialogsCount: unreadCount,
                    onTabSelected: { currentTab = $0 }
                )
            }
        }
        .preferredColorScheme(preferredScheme)
        .sheet(isPresented: $showAddOrEditModal) {
            AddOrEditItemSheet(
                initialItem: editingItem,
                availableZones: ["Гараж", "Склад 1", "Ангар", "Стеллаж А"] + viewModel.zones.map(\.name),
                onDismiss: { showAddOrEditModal = false },
                onSave: { item in
                    viewModel.saveItem(item) {
                        showAddOrEditModal = false
                    }
                },
                onDelete: editingItem != nil ? { id in
                    viewModel.deleteItem(itemId: id)
                    showAddOrEditModal = false
                } : nil
            )
        }
        .sheet(item: $photoHintItem) { item in
            PhotoHintSheet(
                item: item,
                onDismiss: { photoHintItem = nil },
                onUpdateHint: { updated in
                    viewModel.saveItem(updated) {
                        photoHintItem = nil
                    }
                }
            )
        }
        .sheet(item: $editingPlatformType) { pType in
            let existing = viewModel.platforms.first(where: { $0.platformKey == pType.rawValue })
            PlatformConnectionSheet(
                platformType: pType,
                existingConnection: existing,
                onDismiss: { editingPlatformType = nil },
                onSave: { conn in
                    viewModel.savePlatform(conn) {
                        editingPlatformType = nil
                    }
                }
            )
        }
        .sheet(isPresented: $showQrScannerModal) {
            QrScannerSheet(
                items: viewModel.items,
                onDismiss: { showQrScannerModal = false },
                onSelectItem: { item in
                    showQrScannerModal = false
                    photoHintItem = item
                },
                onCreateNewWithCode: { scanned in
                    showQrScannerModal = false
                    editingItem = GarageItem(qrCode: scanned)
                    showAddOrEditModal = true
                }
            )
        }
        .sheet(isPresented: $showCreateDialogModal) {
            CreateBuyerDialogSheet(
                items: viewModel.items,
                onDismiss: { showCreateDialogModal = false },
                onCreate: { dialog in
                    viewModel.createDialog(dialog) {
                        showCreateDialogModal = false
                    }
                }
            )
        }
        .sheet(isPresented: $showPromotionModal) {
            PromotionBoostSheet(
                items: viewModel.items,
                onDismiss: { showPromotionModal = false },
                onBoostItem: { item in
                    viewModel.boostItemPromotion(item)
                }
            )
        }
        .overlay(alignment: .bottom) {
            if let toast = viewModel.statusToast {
                Text(toast)
                    .font(.system(size: 13, weight: .bold))
                    .foregroundColor(.white)
                    .padding(.horizontal, 16)
                    .padding(.vertical, 10)
                    .background(GarageTheme.cardElevated.opacity(0.96))
                    .clipShape(Capsule())
                    .overlay(
                        Capsule()
                            .stroke(GarageTheme.orange.opacity(0.6), lineWidth: 1)
                    )
                    .shadow(radius: 8)
                    .padding(.bottom, 78)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
                    .onAppear {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
                            withAnimation {
                                viewModel.statusToast = nil
                            }
                        }
                    }
            }
        }
    }
}

private struct GarageBottomBarIOS: View {
    let currentTab: GarageMainTab
    let unreadDialogsCount: Int
    let onTabSelected: (GarageMainTab) -> Void

    var body: some View {
        VStack(spacing: 0) {
            Rectangle()
                .fill(GarageTheme.outline.opacity(0.8))
                .frame(height: 1)

            HStack(spacing: 0) {
                ForEach(GarageMainTab.allCases) { tab in
                    let isSelected = currentTab == tab
                    Button {
                        onTabSelected(tab)
                    } label: {
                        VStack(spacing: 4) {
                            ZStack(alignment: .topTrailing) {
                                RoundedRectangle(cornerRadius: 12, style: .continuous)
                                    .fill(isSelected ? GarageTheme.orange.opacity(0.18) : Color.clear)
                                    .frame(width: 48, height: 28)
                                    .overlay(
                                        Image(systemName: tab.systemImage)
                                            .font(.system(size: 17, weight: .semibold))
                                            .foregroundColor(isSelected ? GarageTheme.orange : GarageTheme.textSecondary)
                                    )

                                if tab == .dialogs && unreadDialogsCount > 0 {
                                    ZStack {
                                        Circle()
                                            .fill(GarageTheme.dangerRed)
                                            .frame(width: 15, height: 15)
                                        Text(unreadDialogsCount > 9 ? "9+" : "\(unreadDialogsCount)")
                                            .font(.system(size: 8.5, weight: .extrabold))
                                            .foregroundColor(.white)
                                    }
                                    .offset(x: 4, y: -3)
                                }
                            }

                            Text(tab.label)
                                .font(.system(size: 10.5, weight: isSelected ? .bold : .medium))
                                .foregroundColor(isSelected ? GarageTheme.orange : GarageTheme.textSecondary)
                                .lineLimit(1)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 6)
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.horizontal, 6)
            .background(Color(red: 18/255, green: 21/255, blue: 28/255))
        }
    }
}
