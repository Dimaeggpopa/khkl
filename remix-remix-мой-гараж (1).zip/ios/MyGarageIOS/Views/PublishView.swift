import SwiftUI

struct PublishView: View {
    @ObservedObject var viewModel: GarageViewModel
    let onEditItem: (GarageItem) -> Void
    let onOpenPhotoHint: (GarageItem) -> Void
    let onOpenPlatformSettings: (PlatformType) -> Void

    @State private var searchQuery: String = ""
    @State private var selectedFilter: String = "Все товары"

    private var selectedCount: Int {
        viewModel.items.filter(\.isSelectedForPublish).count
    }

    private var activePlatformsCount: Int {
        let count = viewModel.platforms.filter { $0.isConnected && $0.isSelectedForUpload }.count
        return count == 0 ? 4 : count
    }

    private var filteredItems: [GarageItem] {
        viewModel.items.filter { item in
            let matchesSearch = searchQuery.trimmingCharacters(in: .whitespaces).isEmpty ||
                item.title.localizedCaseInsensitiveContains(searchQuery) ||
                item.qrCode.localizedCaseInsensitiveContains(searchQuery) ||
                item.barcode.localizedCaseInsensitiveContains(searchQuery) ||
                item.shelfLocation.localizedCaseInsensitiveContains(searchQuery)

            let matchesTab: Bool = {
                switch selectedFilter {
                case _ where selectedFilter.hasPrefix("Выбранные"):
                    return item.isSelectedForPublish
                case "Черновики":
                    return item.publicationStatus == "draft" || item.publishedPlatforms.isEmpty
                case "Ошибки":
                    return item.publicationStatus == "error"
                default:
                    return true
                }
            }()

            return matchesSearch && matchesTab
        }
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                // Header
                HStack(spacing: 4) {
                    Text("ПУБЛИКАЦИЯ")
                        .font(.system(size: 16, weight: .bold, design: .rounded))
                        .foregroundColor(GarageTheme.textPrimary)
                    Text(" | Активных площадок: \(activePlatformsCount)")
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(GarageTheme.textSecondary)
                }
                .padding(.top, 4)

                // Select platforms row
                VStack(alignment: .leading, spacing: 10) {
                    HStack {
                        Text("Выберите площадки для выгрузки:")
                            .font(.system(size: 13.5, weight: .semibold))
                            .foregroundColor(GarageTheme.textSecondary)

                        Spacer()

                        HStack(spacing: 14) {
                            ForEach(PlatformType.allCases) { pType in
                                let conn = viewModel.platforms.first(where: { $0.platformKey == pType.rawValue })
                                let isSelected = conn?.isSelectedForUpload ?? true
                                PlatformBadgeIcon(
                                    platformType: pType,
                                    size: 40,
                                    showCheckmark: true,
                                    isConnected: isSelected,
                                    onClick: {
                                        if let conn = conn {
                                            viewModel.togglePlatformForUpload(conn)
                                        } else {
                                            onOpenPlatformSettings(pType)
                                        }
                                    }
                                )
                            }
                        }
                    }

                    HStack {
                        Text("Нажмите галочку для включения в пакет")
                            .font(.system(size: 11))
                            .foregroundColor(GarageTheme.textSecondary)

                        Spacer()

                        Button {
                            onOpenPlatformSettings(.avito)
                        } label: {
                            Text("Настроить API ключи →")
                                .font(.system(size: 11, weight: .bold))
                                .foregroundColor(GarageTheme.electricBlue)
                        }
                        .buttonStyle(.plain)
                    }
                }

                // 1-Click Publish Selected Button
                OneClickPublishGradientButton(
                    text: viewModel.publishProgress.isPublishing
                        ? viewModel.publishProgress.currentStepText
                        : "ОПУБЛИКОВАТЬ ВЫБРАННОЕ (\(selectedCount))",
                    subtitle: "в 1 клик на все выбранные площадки без ошибок",
                    isPublishing: viewModel.publishProgress.isPublishing,
                    onClick: { viewModel.publishAllInOneClick(onlySelected: true) }
                )

                if viewModel.publishProgress.isPublishing {
                    ProgressView(value: viewModel.publishProgress.progressFraction)
                        .tint(GarageTheme.orange)
                        .frame(height: 6)
                }

                // Search bar
                HStack(spacing: 8) {
                    Image(systemName: "magnifyingglass")
                        .font(.system(size: 15))
                        .foregroundColor(GarageTheme.textSecondary)

                    TextField("Поиск товаров для публикации (название, QR, штрихкод)...", text: $searchQuery)
                        .font(.system(size: 13))
                        .foregroundColor(GarageTheme.textPrimary)
                        .autocorrectionDisabled()
                }
                .padding(.horizontal, 12)
                .frame(height: 46)
                .background(GarageTheme.cardBg)
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                        .stroke(GarageTheme.outline, lineWidth: 1)
                )

                // Filter chips
                let filterTabs = ["Все товары", "Выбранные (\(selectedCount))", "Черновики", "Ошибки"]
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(filterTabs, id: \.self) { tab in
                            let isSelected = selectedFilter == tab ||
                                (tab.hasPrefix("Выбранные") && selectedFilter.hasPrefix("Выбранные"))
                            Button {
                                selectedFilter = tab
                            } label: {
                                Text(tab)
                                    .font(.system(size: 12, weight: isSelected ? .bold : .medium))
                                    .foregroundColor(isSelected ? .white : GarageTheme.textSecondary)
                                    .padding(.horizontal, 14)
                                    .padding(.vertical, 8)
                                    .background(isSelected ? GarageTheme.orange : GarageTheme.cardBg)
                                    .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 10, style: .continuous)
                                            .stroke(isSelected ? GarageTheme.orange : GarageTheme.outline, lineWidth: 1)
                                    )
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }

                // Selectable Item Cards
                if filteredItems.isEmpty {
                    VStack(spacing: 6) {
                        Text("В этой категории пока нет товаров")
                            .font(.system(size: 14, weight: .bold, design: .rounded))
                            .foregroundColor(GarageTheme.textPrimary)
                        Text("Все объявления синхронизированы без ошибок!")
                            .font(.system(size: 12))
                            .foregroundColor(GarageTheme.textSecondary)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(20)
                    .background(GarageTheme.cardBg)
                    .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                } else {
                    ForEach(filteredItems) { item in
                        PublishSelectableItemCardIOS(
                            item: item,
                            onToggleSelect: { viewModel.toggleItemSelectionForPublish(item) },
                            onCardClick: { onEditItem(item) },
                            onPhotoHintClick: { onOpenPhotoHint(item) }
                        )
                    }
                }
            }
            .padding(.horizontal, 16)
            .padding(.top, 8)
            .padding(.bottom, 24)
        }
    }
}

private struct PublishSelectableItemCardIOS: View {
    let item: GarageItem
    let onToggleSelect: () -> Void
    let onCardClick: () -> Void
    let onPhotoHintClick: () -> Void

    private var statusInfo: (Color, String) {
        switch item.publicationStatus {
        case "published":
            return (GarageTheme.emeraldGreen, "Статус: Опубликовано везде")
        case "partial":
            return (GarageTheme.amber, "Статус: Опубликовано частично")
        default:
            return (GarageTheme.textSecondary, "Статус: Черновик")
        }
    }

    var body: some View {
        HStack(alignment: .center, spacing: 10) {
            // Circular checkbox on left
            Button(action: onToggleSelect) {
                ZStack {
                    Circle()
                        .fill(item.isSelectedForPublish ? GarageTheme.electricBlue : Color.clear)
                        .frame(width: 26, height: 26)
                        .overlay(
                            Circle()
                                .stroke(item.isSelectedForPublish ? GarageTheme.electricBlue : GarageTheme.textSecondary, lineWidth: 2)
                        )
                    if item.isSelectedForPublish {
                        Image(systemName: "checkmark")
                            .font(.system(size: 12, weight: .black))
                            .foregroundColor(.white)
                    }
                }
            }
            .buttonStyle(.plain)

            // 86pt Thumbnail
            ItemThumbnailBox(
                photoUri: item.photoUri,
                title: item.title,
                width: 86,
                height: 86,
                cornerRadius: 12
            )

            // Right details
            VStack(alignment: .leading, spacing: 4) {
                Text(item.title)
                    .font(.system(size: 14, weight: .bold, design: .rounded))
                    .foregroundColor(GarageTheme.textPrimary)
                    .lineLimit(2)

                Text(formatRubles(item.price))
                    .font(.system(size: 14.5, weight: .extrabold, design: .rounded))
                    .foregroundColor(GarageTheme.emeraldGreen)

                HStack(spacing: 4) {
                    Image(systemName: "mappin.and.ellipse")
                        .font(.system(size: 11))
                        .foregroundColor(GarageTheme.textSecondary)
                    Text("Место: \(item.zone), \(item.shelfLocation)")
                        .font(.system(size: 10.5))
                        .foregroundColor(GarageTheme.textSecondary)
                        .lineLimit(1)
                }

                HStack {
                    Text("QR: \(item.qrCode)")
                        .font(.system(size: 10))
                        .foregroundColor(GarageTheme.textSecondary)
                    Spacer()
                    MiniBarcodeCanvas(
                        code: item.barcode.isEmpty ? item.qrCode : item.barcode,
                        width: 36,
                        height: 15
                    )
                }

                PhotoHintChip(label: "Фото-подсказка", onClick: onPhotoHintClick)
                    .padding(.top, 2)

                HStack {
                    HStack(spacing: 4) {
                        Circle()
                            .fill(statusInfo.0)
                            .frame(width: 7, height: 7)
                        Text(statusInfo.1)
                            .font(.system(size: 10))
                            .foregroundColor(GarageTheme.textSecondary)
                            .lineLimit(1)
                    }

                    Spacer()

                    HStack(spacing: 4) {
                        ForEach(PlatformType.allCases) { pType in
                            let isPub = item.publishedPlatforms.contains(pType.rawValue)
                            PlatformBadgeIcon(
                                platformType: pType,
                                size: 17,
                                showStatusDot: false,
                                isConnected: isPub
                            )
                        }
                    }
                }
                .padding(.top, 2)
            }
        }
        .padding(12)
        .background(GarageTheme.cardBg)
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .stroke(
                    item.isSelectedForPublish ? GarageTheme.electricBlue.opacity(0.6) : GarageTheme.outline,
                    lineWidth: 1
                )
        )
        .contentShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
        .onTapGesture(perform: onCardClick)
    }
}
