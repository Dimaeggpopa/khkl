import SwiftUI

struct HomeView: View {
    @ObservedObject var viewModel: GarageViewModel
    let onAddItem: () -> Void
    let onEditItem: (GarageItem) -> Void
    let onOpenPhotoHint: (GarageItem) -> Void
    let onOpenQrScanner: () -> Void
    let onOpenPlatformSettings: (PlatformType) -> Void
    let onOpenPromotion: () -> Void
    let onNavigateToDialogs: () -> Void

    @State private var searchQuery: String = ""
    @State private var showOnlyUnpublished: Bool = false

    private var filteredItems: [GarageItem] {
        viewModel.items.filter { item in
            let matchesSearch = searchQuery.trimmingCharacters(in: .whitespaces).isEmpty ||
                item.title.localizedCaseInsensitiveContains(searchQuery) ||
                item.qrCode.localizedCaseInsensitiveContains(searchQuery) ||
                item.barcode.localizedCaseInsensitiveContains(searchQuery) ||
                item.serialCode.localizedCaseInsensitiveContains(searchQuery) ||
                item.shelfLocation.localizedCaseInsensitiveContains(searchQuery)
            let matchesFilter = !showOnlyUnpublished || item.publishedPlatforms.count < 4
            return matchesSearch && matchesFilter
        }
    }

    private var unreadMessagesCount: Int64 {
        viewModel.dialogs.reduce(0) { $0 + $1.unreadCount }
    }

    private var totalViews: Int64 {
        viewModel.items.reduce(0) { $0 + $1.viewsCount }
    }

    private var totalInquiries: Int64 {
        viewModel.items.reduce(0) { $0 + $1.inquiriesCount }
    }

    var body: some View {
        ZStack(alignment: .bottom) {
            ScrollView {
                VStack(alignment: .leading, spacing: 14) {
                    // 1. Connected platforms row
                    VStack(alignment: .leading, spacing: 10) {
                        HStack {
                            Text("Подключенные площадки:")
                                .font(.system(size: 13.5, weight: .semibold))
                                .foregroundColor(GarageTheme.textSecondary)

                            Spacer()

                            HStack(spacing: 14) {
                               ForEach(PlatformType.allCases) { pType in
                                    let conn = viewModel.platforms.first(where: { $0.platformKey == pType.rawValue })
                                    let isConnected = conn?.isConnected ?? true
                                    PlatformBadgeIcon(
                                        platformType: pType,
                                        size: 38,
                                        showStatusDot: true,
                                        isConnected: isConnected,
                                        onClick: { onOpenPlatformSettings(pType) }
                                    )
                                }
                            }
                        }

                        HStack {
                            Text("Всего просмотров: \(totalViews) • Запросов: \(totalInquiries)")
                                .font(.system(size: 11, weight: .medium))
                                .foregroundColor(GarageTheme.textSecondary)

                            Spacer()

                            Text("Нажмите на иконку для API")
                                .font(.system(size: 11, weight: .bold))
                                .foregroundColor(GarageTheme.electricBlue)
                        }
                    }
                    .padding(.top, 4)

                    // 2. One-click publish gradient button
                    OneClickPublishGradientButton(
                        text: viewModel.publishProgress.isPublishing
                            ? viewModel.publishProgress.currentStepText
                            : "ОПУБЛИКОВАТЬ ВСЁ В 1 КЛИК",
                        subtitle: viewModel.publishProgress.isPublishing
                            ? "Синхронизация без ошибок и потерь..."
                            : "Авито • Юла • ВК Маркет • Яндекс (\(viewModel.items.count) тов.)",
                        isPublishing: viewModel.publishProgress.isPublishing,
                        onClick: { viewModel.publishAllInOneClick(onlySelected: false) }
                    )

                    if viewModel.publishProgress.isPublishing {
                        ProgressView(value: viewModel.publishProgress.progressFraction)
                            .tint(GarageTheme.orange)
                            .frame(height: 6)
                    }

                    // 3. Quick access section
                    VStack(alignment: .leading, spacing: 8) {
                        Text("БЫСТРЫЙ ДОСТУП")
                            .font(.system(size: 12, weight: .bold, design: .rounded))
                            .foregroundColor(GarageTheme.textPrimary)

                        HStack(spacing: 10) {
                            QuickAccessCardIOS(
                                icon: "plus",
                                iconTint: GarageTheme.orange,
                                title: "Добавить\nтовар",
                                onClick: onAddItem
                            )
                            QuickAccessCardIOS(
                                icon: "qrcode.viewfinder",
                                iconTint: GarageTheme.electricBlue,
                                title: "Скан QR /\nкода",
                                onClick: onOpenQrScanner
                            )
                            QuickAccessCardIOS(
                                icon: "chart.line.uptrend.xyaxis",
                                iconTint: GarageTheme.orange,
                                title: "Продвижение",
                                onClick: onOpenPromotion
                            )
                        }
                    }

                    // 4. MY GARAGE & WAREHOUSE + Search + Filter
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Text("МОЙ ГАРАЖ И СКЛАД")
                                .font(.system(size: 12, weight: .bold, design: .rounded))
                                .foregroundColor(GarageTheme.textPrimary)
                            Spacer()
                            Text("Товаров: \(filteredItems.count)")
                                .font(.system(size: 11, weight: .medium))
                                .foregroundColor(GarageTheme.textSecondary)
                        }

                        HStack(spacing: 8) {
                            HStack(spacing: 8) {
                                Image(systemName: "magnifyingglass")
                                    .font(.system(size: 15))
                                    .foregroundColor(GarageTheme.textSecondary)

                                TextField("Поиск по складу (название, QR, штрихкод, ID)...", text: $searchQuery)
                                    .font(.system(size: 13))
                                    .foregroundColor(GarageTheme.textPrimary)
                                    .autocorrectionDisabled()
                            }
                            .padding(.horizontal, 12)
                            .frame(height: 46)
                            .background(GarageTheme.cardBg)
                            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                            .overlay(
                                RoundedRectangle(cornerRadius: 12, style: .continuous)
                                    .stroke(GarageTheme.outline, lineWidth: 1)
                            )

                            Button {
                                showOnlyUnpublished.toggle()
                            } label: {
                                ZStack {
                                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                                        .fill(showOnlyUnpublished ? GarageTheme.orange.opacity(0.2) : GarageTheme.cardBg)
                                        .frame(width: 46, height: 46)
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 12, style: .continuous)
                                                .stroke(showOnlyUnpublished ? GarageTheme.orange : GarageTheme.outline, lineWidth: 1)
                                        )

                                    Image(systemName: "line.3.horizontal.decrease.circle")
                                        .font(.system(size: 19, weight: .semibold))
                                        .foregroundColor(showOnlyUnpublished ? GarageTheme.orange : GarageTheme.textSecondary)
                                }
                            }
                            .buttonStyle(.plain)
                        }
                    }

                    // 5. 2-Column Grid of items
                    if filteredItems.isEmpty {
                        VStack(spacing: 8) {
                            Text("Товары не найдены")
                                .font(.system(size: 15, weight: .bold, design: .rounded))
                                .foregroundColor(GarageTheme.textPrimary)
                            Text("Добавьте первый товар в гараж или измените запрос поиска")
                                .font(.system(size: 12))
                                .foregroundColor(GarageTheme.textSecondary)
                                .multilineTextAlignment(.center)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(24)
                        .background(GarageTheme.cardBg)
                        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                    } else {
                        LazyVGrid(
                            columns: [
                                GridItem(.flexible(), spacing: 10),
                                GridItem(.flexible(), spacing: 10)
                            ],
                            spacing: 10
                        ) {
                            ForEach(filteredItems) { item in
                                HomeGarageGridCardIOS(
                                    item: item,
                                    onCardClick: { onEditItem(item) },
                                    onPhotoHintClick: { onOpenPhotoHint(item) }
                                )
                            }
                        }
                    }
                }
                .padding(.horizontal, 16)
                .padding(.top, 8)
                .padding(.bottom, 90)
            }

            // 6. Bottom Unified Messages Bar
            Button(action: onNavigateToDialogs) {
                HStack {
                    HStack(spacing: 8) {
                        Image(systemName: "bubble.left.and.bubble.right.fill")
                            .font(.system(size: 18, weight: .semibold))
                            .foregroundColor(GarageTheme.electricBlue)

                        let badgeText = unreadMessagesCount > 0
                            ? "Единые сообщения (\(unreadMessagesCount) новых)"
                            : "Единые сообщения (все чаты)"
                        Text(badgeText)
                            .font(.system(size: 13.5, weight: .bold, design: .rounded))
                            .foregroundColor(GarageTheme.textPrimary)
                            .lineLimit(1)
                    }

                    Spacer()

                    HStack(spacing: -6) {
                        ForEach(PlatformType.allCases) { pType in
                            PlatformBadgeIcon(
                                platformType: pType,
                                size: 22,
                                showStatusDot: false
                            )
                        }
                        Image(systemName: "chevron.right")
                            .font(.system(size: 13, weight: .bold))
                            .foregroundColor(GarageTheme.textSecondary)
                            .padding(.leading, 10)
                    }
                }
                .padding(.horizontal, 14)
                .padding(.vertical, 12)
                .background(Color(red: 28/255, green: 33/255, blue: 45/255))
                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                        .stroke(GarageTheme.electricBlue.opacity(0.45), lineWidth: 1)
                )
                .shadow(color: .black.opacity(0.35), radius: 8, y: 4)
            }
            .buttonStyle(.plain)
            .padding(.horizontal, 16)
            .padding(.bottom, 10)
        }
    }
}

private struct QuickAccessCardIOS: View {
    let icon: String
    let iconTint: Color
    let title: String
    let onClick: () -> Void

    var body: some View {
        Button(action: onClick) {
            VStack(spacing: 6) {
                ZStack {
                    Circle()
                        .fill(iconTint.opacity(0.16))
                        .frame(width: 34, height: 34)
                    Image(systemName: icon)
                        .font(.system(size: 16, weight: .bold))
                        .foregroundColor(iconTint)
                }

                Text(title)
                    .font(.system(size: 11, weight: .semibold, design: .rounded))
                    .foregroundColor(GarageTheme.textPrimary)
                    .multilineTextAlignment(.center)
                    .lineSpacing(1)
                    .lineLimit(2)
            }
            .frame(maxWidth: .infinity)
            .frame(height: 82)
            .padding(.horizontal, 6)
            .background(GarageTheme.cardBg)
            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .stroke(GarageTheme.outline, lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
    }
}

private struct HomeGarageGridCardIOS: View {
    let item: GarageItem
    let onCardClick: () -> Void
    let onPhotoHintClick: () -> Void

    private var statusInfo: (Color, String) {
        switch item.publicationStatus {
        case "published":
            return (GarageTheme.emeraldGreen, "Статус: Опубликовано везде")
        case "partial":
            return (GarageTheme.amber, "Статус: Опубликовано частично")
        default:
            return (GarageTheme.textSecondary, "Статус: Черновик на складе")
        }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(item.title)
                .font(.system(size: 13, weight: .bold, design: .rounded))
                .foregroundColor(GarageTheme.textPrimary)
                .lineLimit(2)
                .frame(minHeight: 34, alignment: .topLeading)

            Text(formatRubles(item.price))
                .font(.system(size: 14, weight: .extrabold, design: .rounded))
                .foregroundColor(GarageTheme.emeraldGreen)

            HStack(alignment: .top, spacing: 4) {
                Image(systemName: "mappin.and.ellipse")
                    .font(.system(size: 11))
                    .foregroundColor(GarageTheme.textSecondary)
                Text("Место: \(item.zone), \(item.shelfLocation)")
                    .font(.system(size: 10.5))
                    .foregroundColor(GarageTheme.textSecondary)
                    .lineLimit(2)
            }

            HStack {
                Text("QR: \(item.qrCode)")
                    .font(.system(size: 10, weight: .medium))
                    .foregroundColor(GarageTheme.textSecondary)
                    .lineLimit(1)

                Spacer()

                if !item.barcode.isEmpty {
                    MiniBarcodeCanvas(code: item.barcode, width: 32, height: 15)
                } else {
                    MiniQrCodeCanvas(code: item.qrCode, size: 18)
                }
            }

            HStack(spacing: 5) {
                Circle()
                    .fill(statusInfo.0)
                    .frame(width: 7, height: 7)
                Text(statusInfo.1)
                    .font(.system(size: 10, weight: .medium))
                    .foregroundColor(GarageTheme.textSecondary)
                    .lineLimit(1)
            }

            ZStack(alignment: .bottomLeading) {
                ItemThumbnailBox(
                    photoUri: item.photoUri,
                    title: item.title,
                    height: 64,
                    cornerRadius: 10
                )

                PhotoHintChip(label: "Фото-подсказка", onClick: onPhotoHintClick)
                    .padding(4)
            }
            .padding(.top, 2)
        }
        .padding(11)
        .background(GarageTheme.cardBg)
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .stroke(GarageTheme.outline, lineWidth: 1)
        )
        .contentShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
        .onTapGesture(perform: onCardClick)
    }
}
