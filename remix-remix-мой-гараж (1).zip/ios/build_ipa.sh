#!/usr/bin/env bash
set -euo pipefail

echo "=== Сборка Мой гараж для iPhone (iOS .ipa) ==="
cd "$(dirname "$0")"

if ! command -v xcodegen >/dev/null 2>&1; then
  echo "Установка XcodeGen..."
  brew install xcodegen
fi

echo "[1/3] Генерация Xcode-проекта MyGarageIOS.xcodeproj через XcodeGen..."
xcodegen generate

echo "[2/3] Компиляция и архивация iOS-приложения..."
xcodebuild archive \
  -project MyGarageIOS.xcodeproj \
  -scheme MyGarageIOS \
  -configuration Release \
  -archivePath ./build/MyGarageIOS.xcarchive \
  -destination "generic/platform=iOS" \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY="" \
  AD_HOC_CODE_SIGNING_ALLOWED=YES

echo "[3/3] Упаковка Payload в MyGarageIOS.ipa..."
rm -rf ./build/ipa ./build/MyGarageIOS.ipa
mkdir -p ./build/ipa/Payload
cp -R ./build/MyGarageIOS.xcarchive/Products/Applications/MyGarageIOS.app ./build/ipa/Payload/
(cd ./build/ipa && zip -qr ../MyGarageIOS.ipa Payload)

echo "Готово! Файл для установки на iPhone создан: $(pwd)/build/MyGarageIOS.ipa"
ls -lh ./build/MyGarageIOS.ipa
