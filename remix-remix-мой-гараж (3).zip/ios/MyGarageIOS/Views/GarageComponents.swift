import SwiftUI
import UIKit

enum GarageTheme {
    static let background = Color(red: 14/255, green: 16/255, blue: 21/255)      // #0E1015
    static let surface = Color(red: 21/255, green: 24/255, blue: 33/255)         // #151821
    static let cardBg = Color(red: 24/255, green: 28/255, blue: 38/255)          // #181C26
    static let cardElevated = Color(red: 31/255, green: 36/255, blue: 48/255)    // #1F2430
    static let outline = Color(red: 38/255, green: 44/255, blue: 58/255)         // #262C3A
    static let textPrimary = Color(red: 243/255, green: 245/255, blue: 248/255)  // #F3F5F8
    static let textSecondary = Color(red: 148/255, green: 155/255, blue: 168/255)// #949BA8

    static let orange = Color(red: 1.0, green: 107/255, blue: 0.0)               // #FF6B00
    static let orangeBright = Color(red: 1.0, green: 133/255, blue: 27/255)      // #FF851B
    static let electricBlue = Color(red: 10/255, green: 132/255, blue: 1.0)      // #0A84FF
    static let emeraldGreen = Color(red: 48/255, green: 209/255, blue: 88/255)   // #30D158
    static let amber = Color(red: 245/255, green: 158/255, blue: 11/255)         // #F59E0B
    static let dangerRed = Color(red: 1.0, green: 69/255, blue: 58/255)          // #FF453A
}

struct GarageTopBar: View {
    var title: String = "Мой гараж"
    var unreadNotificationsCount: Int = 0
    var userInitials: String = "МГ"
    var onNotificationsClick: () -> Void
    var onProfileClick: () -> Void

    var body: some View {
        HStack(spacing: 10) {
            HStack(spacing: 10) {
                GarageBrandLogo(size: 36)
                Text(title)
                    .font(.system(size: 20, weight: .heavy, design: .rounded))
                    .foregroundColor(GarageTheme.textPrimary)
            }

            Spacer()

            HStack(spacing: 10) {
                Button(action: onProfileClick) {
                    ZStack {
                        Circle()
                            .fill(
                                LinearGradient(
                                    colors: [Color(red: 43/255, green: 50/255, blue: 66/255),
                                             Color(red: 26/255, green: 30/255, blue: 41/255)],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                )
                            )
                            .frame(width: 36, height: 36)
                            .overlay(
                                Circle()
                                    .stroke(GarageTheme.electricBlue.opacity(0.6), lineWidth: 1.5)
                            )

                        Text(userInitials)
                            .font(.system(size: 13, weight: .bold, design: .rounded))
                            .foregroundColor(.white)
                    }
                }
                .buttonStyle(.plain)

                Button(action: onNotificationsClick) {
                    ZStack(alignment: .topTrailing) {
                        RoundedRectangle(cornerRadius: 11, style: .continuous)
                            .fill(GarageTheme.cardBg)
                            .frame(width: 38, height: 38)
                            .overlay(
                                RoundedRectangle(cornerRadius: 11, style: .continuous)
                                    .stroke(GarageTheme.outline, lineWidth: 1)
                            )
                            .overlay(
                                Image(systemName: "bell")
                                    .font(.system(size: 17, weight: .semibold))
                                    .foregroundColor(GarageTheme.textPrimary)
                            )

                        if unreadNotificationsCount > 0 {
                            ZStack {
                                Circle()
                                    .fill(GarageTheme.dangerRed)
                                    .frame(width: 17, height: 17)
                                Text(unreadNotificationsCount > 9 ? "9+" : "\(unreadNotificationsCount)")
                                    .font(.system(size: 9, weight: .heavy))
                                    .foregroundColor(.white)
                            }
                            .offset(x: 4, y: -4)
                        }
                    }
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
        .background(GarageTheme.background)
    }
}

struct GarageBrandLogo: View {
    var size: CGFloat = 36

    var body: some View {
        Canvas { context, canvasSize in
            let w = canvasSize.width
            let h = canvasSize.height

            // Outer metallic silver garage frame
            var roofPath = Path()
            roofPath.move(to: CGPoint(x: w * 0.08, y: h * 0.36))
            roofPath.addLine(to: CGPoint(x: w * 0.50, y: h * 0.10))
            roofPath.addLine(to: CGPoint(x: w * 0.92, y: h * 0.36))
            roofPath.addLine(to: CGPoint(x: w * 0.92, y: h * 0.88))
            roofPath.addLine(to: CGPoint(x: w * 0.78, y: h * 0.88))
            roofPath.addLine(to: CGPoint(x: w * 0.78, y: h * 0.42))
            roofPath.addLine(to: CGPoint(x: w * 0.50, y: h * 0.25))
            roofPath.addLine(to: CGPoint(x: w * 0.22, y: h * 0.42))
            roofPath.addLine(to: CGPoint(x: w * 0.22, y: h * 0.88))
            roofPath.addLine(to: CGPoint(x: w * 0.08, y: h * 0.88))
            roofPath.closeSubpath()

            context.fill(
                roofPath,
                with: .linearGradient(
                    Gradient(colors: [
                        Color(red: 232/255, green: 236/255, blue: 242/255),
                        Color(red: 154/255, green: 164/255, blue: 178/255)
                    ]),
                    startPoint: .zero,
                    endPoint: CGPoint(x: w, y: h)
                )
            )

            // Horizontal roof shutter lines
            for i in 0...1 {
                let y = h * (0.37 + CGFloat(i) * 0.07)
                let rect = CGRect(x: w * 0.30, y: y, width: w * 0.40, height: h * 0.035)
                context.fill(
                    Path(roundedRect: rect, cornerRadius: 2),
                    with: .color(Color(red: 184/255, green: 194/255, blue: 208/255))
                )
            }

            // Orange toolbox body inside garage
            let boxRect = CGRect(x: w * 0.27, y: h * 0.54, width: w * 0.46, height: h * 0.34)
            context.fill(
                Path(roundedRect: boxRect, cornerRadius: w * 0.06),
                with: .linearGradient(
                    Gradient(colors: [
                        Color(red: 1.0, green: 138/255, blue: 0.0),
                        Color(red: 230/255, green: 81/255, blue: 0.0)
                    ]),
                    startPoint: CGPoint(x: 0, y: h * 0.54),
                    endPoint: CGPoint(x: 0, y: h * 0.88)
                )
            )

            // Toolbox center latch
            let latchRect = CGRect(x: w * 0.44, y: h * 0.65, width: w * 0.12, height: h * 0.09)
            context.fill(
                Path(roundedRect: latchRect, cornerRadius: 2),
                with: .color(.white)
            )
        }
        .frame(width: size, height: size)
    }
}

struct PlatformBadgeIcon: View {
    let platformType: PlatformType
    var size: CGFloat = 38
    var showStatusDot: Bool = false
    var showCheckmark: Bool = false
    var isConnected: Bool = true
    var onClick: (() -> Void)? = nil

    var body: some View {
        ZStack(alignment: .bottomTrailing) {
            Group {
                switch platformType {
                case .avito:
                    ZStack {
                        Circle()
                            .fill(Color.white)
                            .frame(width: size, height: size)
                            .overlay(
                                Circle()
                                    .stroke(GarageTheme.outline, lineWidth: 1)
                            )

                        Canvas { context, s in
                            let w = s.width
                            let h = s.height

                            let c1 = CGRect(x: w * 0.31 - w * 0.13, y: h * 0.33 - w * 0.13, width: w * 0.26, height: w * 0.26)
                            context.fill(Path(ellipseIn: c1), with: .color(Color(red: 0, green: 170/255, blue: 1.0)))

                            let c2 = CGRect(x: w * 0.65 - w * 0.17, y: h * 0.34 - w * 0.17, width: w * 0.34, height: w * 0.34)
                            context.fill(Path(ellipseIn: c2), with: .color(Color(red: 1.0, green: 64/255, blue: 83/255)))

                            let c3 = CGRect(x: w * 0.34 - w * 0.19, y: h * 0.67 - w * 0.19, width: w * 0.38, height: w * 0.38)
                            context.fill(Path(ellipseIn: c3), with: .color(Color(red: 4/255, green: 224/255, blue: 97/255)))

                            let c4 = CGRect(x: w * 0.67 - w * 0.12, y: h * 0.68 - w * 0.12, width: w * 0.24, height: w * 0.24)
                            context.fill(Path(ellipseIn: c4), with: .color(Color(red: 150/255, green: 94/255, blue: 235/255)))
                        }
                        .frame(width: size * 0.78, height: size * 0.78)
                    }

                case .youla:
                    ZStack {
                        Circle()
                            .fill(GarageTheme.cardElevated)
                            .frame(width: size, height: size)
                            .overlay(
                                Circle()
                                    .stroke(GarageTheme.outline, lineWidth: 1)
                            )

                        Canvas { context, s in
                            let w = s.width
                            let h = s.height
                            var path = Path()
                            path.move(to: CGPoint(x: w * 0.50, y: h * 0.06))
                            path.addLine(to: CGPoint(x: w * 0.65, y: h * 0.35))
                            path.addLine(to: CGPoint(x: w * 0.94, y: h * 0.50))
                            path.addLine(to: CGPoint(x: w * 0.65, y: h * 0.65))
                            path.addLine(to: CGPoint(x: w * 0.50, y: h * 0.94))
                            path.addLine(to: CGPoint(x: w * 0.35, y: h * 0.65))
                            path.addLine(to: CGPoint(x: w * 0.06, y: h * 0.50))
                            path.addLine(to: CGPoint(x: w * 0.35, y: h * 0.35))
                            path.closeSubpath()

                            context.fill(
                                path,
                                with: .linearGradient(
                                    Gradient(colors: [
                                        Color(red: 0, green: 210/255, blue: 1.0),
                                        Color(red: 142/255, green: 45/255, blue: 226/255),
                                        Color(red: 1.0, green: 65/255, blue: 108/255)
                                    ]),
                                    startPoint: .zero,
                                    endPoint: CGPoint(x: w, y: h)
                                )
                            )
                            let hole = CGRect(x: w * 0.34, y: h * 0.34, width: w * 0.32, height: h * 0.32)
                            context.fill(Path(ellipseIn: hole), with: .color(GarageTheme.cardElevated))
                        }
                        .frame(width: size * 0.72, height: size * 0.72)
                    }

                case .vk:
                    ZStack {
                        Circle()
                            .fill(Color(red: 0, green: 119/255, blue: 1.0))
                            .frame(width: size, height: size)
                        Text("VK")
                            .font(.system(size: size * 0.36, weight: .black, design: .rounded))
                            .foregroundColor(.white)
                    }

                case .yandex:
                    ZStack {
                        Circle()
                            .fill(Color(red: 252/255, green: 238/255, blue: 220/255))
                            .frame(width: size, height: size)
                        Circle()
                            .fill(Color(red: 252/255, green: 63/255, blue: 29/255))
                            .frame(width: size * 0.74, height: size * 0.74)
                        Text("Я")
                            .font(.system(size: size * 0.42, weight: .black, design: .rounded))
                            .foregroundColor(.white)
                    }
                }
            }

            if showCheckmark {
                ZStack {
                    Circle()
                        .fill(isConnected ? GarageTheme.emeraldGreen : Color(white: 0.27))
                        .frame(width: size * 0.38, height: size * 0.38)
                        .overlay(
                            Circle()
                                .stroke(GarageTheme.background, lineWidth: 1.5)
                        )
                    Image(systemName: "checkmark")
                        .font(.system(size: size * 0.20, weight: .black))
                        .foregroundColor(.white)
                }
                .offset(x: 2, y: 2)
            } else if showStatusDot {
                Circle()
                    .fill(isConnected ? GarageTheme.emeraldGreen : GarageTheme.amber)
                    .frame(width: size * 0.28, height: size * 0.28)
                    .overlay(
                        Circle()
                            .stroke(GarageTheme.background, lineWidth: 1.5)
                    )
            }
        }
        .frame(width: size, height: size)
        .contentShape(Circle())
        .onTapGesture {
            onClick?()
        }
    }
}

struct OneClickPublishGradientButton: View {
    let text: String
    var subtitle: String? = nil
    var isPublishing: Bool = false
    let onClick: () -> Void

    var body: some View {
        Button(action: onClick) {
            ZStack {
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .fill(
                        LinearGradient(
                            colors: [
                                GarageTheme.orange,
                                GarageTheme.orangeBright,
                                GarageTheme.electricBlue,
                                Color(red: 0, green: 96/255, blue: 223/255)
                            ],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: 18, style: .continuous)
                            .stroke(Color.white.opacity(0.22), lineWidth: 1)
                    )

                HStack(spacing: 10) {
                    if isPublishing {
                        ProgressView()
                            .tint(.white)
                            .scaleEffect(1.1)
                    } else {
                        Image(systemName: "bolt.fill")
                            .font(.system(size: 22, weight: .bold))
                            .foregroundColor(.white)
                    }

                    VStack(alignment: .center, spacing: 2) {
                        Text(text)
                            .font(.system(size: 15, weight: .heavy, design: .rounded))
                            .foregroundColor(.white)
                            .tracking(0.3)
                            .multilineTextAlignment(.center)
                            .lineLimit(2)

                        if let subtitle = subtitle {
                            Text(subtitle)
                                .font(.system(size: 11, weight: .medium))
                                .foregroundColor(Color.white.opacity(0.88))
                                .lineLimit(1)
                        }
                    }
                }
                .padding(.horizontal, 14)
            }
            .frame(maxWidth: .infinity)
            .frame(height: 64)
        }
        .buttonStyle(.plain)
        .disabled(isPublishing)
    }
}

struct MiniQrCodeCanvas: View {
    let code: String
    var size: CGFloat = 24

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 4, style: .continuous)
                .fill(Color.white)
                .frame(width: size, height: size)

            Canvas { context, canvasSize in
                let hash = abs(code.hashValue)
                let cell = canvasSize.width / 5.0
                for r in 0..<5 {
                    for c in 0..<5 {
                        let isCorner = (r < 2 && c < 2) || (r < 2 && c > 2) || (r > 2 && c < 2)
                        let bit = ((hash >> ((r * 5 + c) % 16)) & 1) == 1
                        if isCorner || bit {
                            let rect = CGRect(
                                x: CGFloat(c) * cell,
                                y: CGFloat(r) * cell,
                                width: cell * 0.85,
                                height: cell * 0.85
                            )
                            context.fill(Path(rect), with: .color(Color(red: 17/255, green: 19/255, blue: 24/255)))
                        }
                    }
                }
            }
            .padding(2)
            .frame(width: size, height: size)
        }
    }
}

struct MiniBarcodeCanvas: View {
    let code: String
    var width: CGFloat = 38
    var height: CGFloat = 18

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 3, style: .continuous)
                .fill(Color.white.opacity(0.92))
                .frame(width: width, height: height)

            Canvas { context, canvasSize in
                let hash = abs(code.hashValue)
                let bars = 11
                let barWidth = canvasSize.width / CGFloat(bars * 2)
                for i in 0..<bars {
                    let thick = ((hash >> (i % 8)) & 1) == 1 ? barWidth * 1.4 : barWidth * 0.8
                    let rect = CGRect(
                        x: CGFloat(i * 2) * barWidth,
                        y: 0,
                        width: thick,
                        height: canvasSize.height
                    )
                    context.fill(Path(rect), with: .color(Color(red: 17/255, green: 19/255, blue: 24/255)))
                }
            }
            .padding(.horizontal, 3)
            .padding(.vertical, 2)
            .frame(width: width, height: height)
        }
    }
}

struct ItemThumbnailBox: View {
    let photoUri: String
    let title: String
    var width: CGFloat? = nil
    var height: CGFloat = 80
    var cornerRadius: CGFloat = 12

    private var decodedUIImage: UIImage? {
        guard !photoUri.isEmpty else { return nil }
        if photoUri.hasPrefix("data:image"),
           let commaIndex = photoUri.firstIndex(of: ",") {
            let base64Part = String(photoUri[photoUri.index(after: commaIndex)...])
            if let data = Data(base64Encoded: base64Part) {
                return UIImage(data: data)
            }
        }
        if let data = Data(base64Encoded: photoUri), let img = UIImage(data: data) {
            return img
        }
        return nil
    }

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                .fill(
                    LinearGradient(
                        colors: [
                            Color(red: 34/255, green: 40/255, blue: 54/255),
                            Color(red: 20/255, green: 24/255, blue: 33/255)
                        ],
                        startPoint: .top,
                        endPoint: .bottom
                    )
                )

            if let uiImage = decodedUIImage {
                Image(uiImage: uiImage)
                    .resizable()
                    .scaledToFill()
                    .frame(maxWidth: width ?? .infinity, maxHeight: height)
                    .clipped()
            } else if photoUri.hasPrefix("http"), let url = URL(string: photoUri) {
                AsyncImage(url: url) { phase in
                    switch phase {
                    case .success(let image):
                        image
                            .resizable()
                            .scaledToFill()
                    default:
                        fallbackPlaceholder
                    }
                }
            } else {
                fallbackPlaceholder
            }
        }
        .frame(width: width, height: height)
        .frame(maxWidth: width == nil ? .infinity : nil)
        .clipShape(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                .stroke(GarageTheme.outline, lineWidth: 1)
        )
    }

    private var fallbackPlaceholder: some View {
        VStack(spacing: 4) {
            Image(systemName: "shippingbox.fill")
                .font(.system(size: 22, weight: .semibold))
                .foregroundColor(GarageTheme.orange.opacity(0.85))
            Text(title)
                .font(.system(size: 9, weight: .medium))
                .foregroundColor(GarageTheme.textSecondary)
                .lineLimit(1)
                .truncationMode(.tail)
                .padding(.horizontal, 6)
        }
    }
}

struct PhotoHintChip: View {
    var label: String = "Фото-подсказка"
    let onClick: () -> Void

    var body: some View {
        Button(action: onClick) {
            HStack(spacing: 4) {
                Image(systemName: "camera.fill")
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundColor(GarageTheme.electricBlue)
                Text(label)
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundColor(GarageTheme.textPrimary)
                    .lineLimit(1)
            }
            .padding(.horizontal, 8)
            .padding(.vertical, 4)
            .background(Color(red: 30/255, green: 36/255, blue: 48/255))
            .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 8, style: .continuous)
                    .stroke(GarageTheme.outline, lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
    }
}

struct CupertinoSheetHeader: View {
    let title: String
    let onCancel: () -> Void
    var onDone: (() -> Void)? = nil
    var doneLabel: String = "Готово"

    var body: some View {
        VStack(spacing: 10) {
            Capsule()
                .fill(GarageTheme.textSecondary.opacity(0.35))
                .frame(width: 38, height: 5)
                .padding(.top, 8)

            HStack {
                Button(action: onCancel) {
                    Text("Отмена")
                        .font(.system(size: 15, weight: .medium))
                        .foregroundColor(GarageTheme.electricBlue)
                }
                .buttonStyle(.plain)

                Spacer()

                Text(title)
                    .font(.system(size: 16, weight: .bold, design: .rounded))
                    .foregroundColor(GarageTheme.textPrimary)
                    .lineLimit(1)

                Spacer()

                if let onDone = onDone {
                    Button(action: onDone) {
                        Text(doneLabel)
                            .font(.system(size: 15, weight: .bold))
                            .foregroundColor(GarageTheme.orange)
                    }
                    .buttonStyle(.plain)
                } else {
                    Spacer().frame(width: 56)
                }
            }
            .padding(.horizontal, 4)
        }
    }
}
