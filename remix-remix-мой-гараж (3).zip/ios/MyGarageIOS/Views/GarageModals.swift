import SwiftUI
import PhotosUI
import UIKit

struct AddOrEditItemSheet: View {
    let initialItem: GarageItem?
    let availableZones: [String]
    let onDismiss: () -> Void
    let onSave: (GarageItem) -> Void
    let onDelete: ((String) -> Void)?

    @State private var title: String
    @State private var description: String
    @State private var priceText: String
    @State private var quantityText: String
    @State private var zone: String
    @State private var shelfLocation: String
    @State private var qrCode: String
    @State private var barcode: String
    @State private var serialCode: String
    @State private var hintNote: String
    @State private var photoUri: String
    @State private var hintPhotoUri: String
    @State private var selectedPlatforms: Set<String>

    @State private var selectedItemPhoto: PhotosPickerItem? = nil
    @State private var selectedHintPhoto: PhotosPickerItem? = nil

    init(
        initialItem: GarageItem?,
        availableZones: [String],
        onDismiss: @escaping () -> Void,
        onSave: @escaping (GarageItem) -> Void,
        onDelete: ((String) -> Void)? = nil
    ) {
        self.initialItem = initialItem
        self.availableZones = availableZones
        self.onDismiss = onDismiss
        self.onSave = onSave
        self.onDelete = onDelete

        _title = State(initialValue: initialItem?.title ?? "")
        _description = State(initialValue: initialItem?.description ?? "")
        _priceText = State(initialValue: initialItem != nil && initialItem!.price > 0 ? "\(initialItem!.price)" : "")
        _quantityText = State(initialValue: "\(initialItem?.quantity ?? 1)")
        _zone = State(initialValue: initialItem?.zone ?? (availableZones.first ?? "Гараж"))
        _shelfLocation = State(initialValue: initialItem?.shelfLocation ?? "Стеллаж 1, Полка 2")
        _qrCode = State(initialValue: initialItem?.qrCode.isEmpty == false ? initialItem!.qrCode : GarageRepository.generateQrCode())
        _barcode = State(initialValue: initialItem?.barcode.isEmpty == false ? initialItem!.barcode : GarageRepository.generateBarcode())
        _serialCode = State(initialValue: initialItem?.serialCode ?? "ID-\((1000...9999).randomElement()!)")
        _hintNote = State(initialValue: initialItem?.hintNote ?? "")
        _photoUri = State(initialValue: initialItem?.photoUri ?? "")
        _hintPhotoUri = State(initialValue: initialItem?.hintPhotoUri ?? "")
        _selectedPlatforms = State(initialValue: Set(initialItem?.publishedPlatforms ?? PlatformType.allCases.map(\.rawValue)))
    }

    private func saveAction() {
        let finalTitle = title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            ? "Новый товар на складе"
            : title.trimmingCharacters(in: .whitespacesAndNewlines)
        let finalPrice = Int64(priceText.filter(\.isNumber)) ?? 0
        let finalQty = Int64(quantityText.filter(\.isNumber)) ?? 1
        let pubList = Array(selectedPlatforms)
        let pubStatus: String = {
            if pubList.count >= 4 { return "published" }
            if !pubList.isEmpty { return "partial" }
            return "draft"
        }()

        let item = GarageItem(
            id: initialItem?.id ?? UUID().uuidString,
            userId: initialItem?.userId ?? "",
            title: finalTitle,
            description: description.trimmingCharacters(in: .whitespacesAndNewlines),
            price: finalPrice,
            quantity: finalQty,
            unitLabel: initialItem?.unitLabel ?? "шт.",
            zone: zone,
            shelfLocation: shelfLocation.trimmingCharacters(in: .whitespacesAndNewlines),
            qrCode: qrCode.trimmingCharacters(in: .whitespacesAndNewlines),
            barcode: barcode.trimmingCharacters(in: .whitespacesAndNewlines),
            serialCode: serialCode.trimmingCharacters(in: .whitespacesAndNewlines),
            photoUri: photoUri,
            hintPhotoUri: hintPhotoUri,
            hintNote: hintNote.trimmingCharacters(in: .whitespacesAndNewlines),
            publishedPlatforms: pubList,
            publicationStatus: pubStatus,
            isSelectedForPublish: initialItem?.isSelectedForPublish ?? true,
            viewsCount: initialItem?.viewsCount ?? 0,
            inquiriesCount: initialItem?.inquiriesCount ?? 0,
            isVerifiedInInventory: initialItem?.isVerifiedInInventory ?? false
        )
        onSave(item)
    }

    var body: some View {
        ZStack {
            GarageTheme.surface
                .ignoresSafeArea()

            VStack(spacing: 12) {
                CupertinoSheetHeader(
                    title: initialItem == nil ? "Новый товар" : "Карточка товара",
                    onCancel: onDismiss,
                    onDone: saveAction,
                    doneLabel: "Сохранить"
                )

                ScrollView {
                    VStack(alignment: .leading, spacing: 12) {
                        // Photos Picker row (Item Photo + Shelf Hint Photo)
                        HStack(spacing: 10) {
                            VStack(spacing: 6) {
                                ItemThumbnailBox(
                                    photoUri: photoUri,
                                    title: title.isEmpty ? "Фото товара" : title,
                                    height: 84,
                                    cornerRadius: 12
                                )
                                PhotosPicker(selection: $selectedItemPhoto, matching: .images) {
                                    HStack(spacing: 4) {
                                        Image(systemName: "photo.fill")
                                            .font(.system(size: 12))
                                            .foregroundColor(GarageTheme.orange)
                                        Text(photoUri.isEmpty ? "Фото товара" : "Заменить фото")
                                            .font(.system(size: 11, weight: .bold))
                                            .foregroundColor(GarageTheme.textPrimary)
                                    }
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 8)
                                    .background(GarageTheme.cardBg)
                                    .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 10, style: .continuous)
                                            .stroke(GarageTheme.outline, lineWidth: 1)
                                    )
                                }
                                .buttonStyle(.plain)
                            }

                            VStack(spacing: 6) {
                                ItemThumbnailBox(
                                    photoUri: hintPhotoUri,
                                    title: "Полка: \(zone)",
                                    height: 84,
                                    cornerRadius: 12
                                )
                                PhotosPicker(selection: $selectedHintPhoto, matching: .images) {
                                    HStack(spacing: 4) {
                                        Image(systemName: "camera.fill")
                                            .font(.system(size: 12))
                                            .foregroundColor(GarageTheme.electricBlue)
                                        Text(hintPhotoUri.isEmpty ? "Фото полки" : "Обновить полку")
                                            .font(.system(size: 11, weight: .bold))
                                            .foregroundColor(GarageTheme.textPrimary)
                                    }
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 8)
                                    .background(GarageTheme.cardBg)
                                    .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 10, style: .continuous)
                                            .stroke(GarageTheme.outline, lineWidth: 1)
                                    )
                                }
                                .buttonStyle(.plain)
                            }
                        }

                        GarageFieldBox(label: "Название товара (для склада и площадок)", text: $title)

                        HStack(spacing: 10) {
                            GarageFieldBox(label: "Цена (₽)", text: $priceText, keyboard: .numberPad)
                            GarageFieldBox(label: "Кол-во", text: $quantityText, keyboard: .numberPad)
                                .frame(width: 110)
                        }

                        Text("Зона склада:")
                            .font(.system(size: 12, weight: .bold))
                            .foregroundColor(GarageTheme.textSecondary)

                        let zones = Array(Set(availableZones)).sorted()
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 8) {
                                ForEach(zones, id: \.self) { z in
                                    let isSel = zone == z
                                    Button {
                                        zone = z
                                    } label: {
                                        Text(z)
                                            .font(.system(size: 12, weight: isSel ? .bold : .medium))
                                            .foregroundColor(isSel ? .white : GarageTheme.textSecondary)
                                            .padding(.horizontal, 14)
                                            .padding(.vertical, 8)
                                            .background(isSel ? GarageTheme.orange : GarageTheme.cardBg)
                                            .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                                            .overlay(
                                                RoundedRectangle(cornerRadius: 10, style: .continuous)
                                                    .stroke(isSel ? GarageTheme.orange : GarageTheme.outline, lineWidth: 1)
                                            )
                                    }
                                    .buttonStyle(.plain)
                                }
                            }
                        }

                        GarageFieldBox(label: "Точное место (стеллаж, полка, ряд, бокс)", text: $shelfLocation)

                        GarageFieldBox(label: "Визуальная подсказка (в какой коробке / за чем стоит)", text: $hintNote)

                        HStack(spacing: 10) {
                            GarageFieldBox(label: "QR-код", text: $qrCode)
                            GarageFieldBox(label: "Штрихкод (EAN)", text: $barcode)
                        }

                        Button {
                            qrCode = GarageRepository.generateQrCode()
                            barcode = GarageRepository.generateBarcode()
                        } label: {
                            HStack(spacing: 6) {
                                Image(systemName: "qrcode")
                                    .foregroundColor(GarageTheme.electricBlue)
                                Text("Сгенерировать новый QR и штрихкод")
                                    .font(.system(size: 12, weight: .bold))
                                    .foregroundColor(GarageTheme.textPrimary)
                            }
                            .frame(maxWidth: .infinity)
                            .frame(height: 40)
                            .background(GarageTheme.cardBg)
                            .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                            .overlay(
                                RoundedRectangle(cornerRadius: 10, style: .continuous)
                                    .stroke(GarageTheme.outline, lineWidth: 1)
                            )
                        }
                        .buttonStyle(.plain)

                        GarageFieldBox(label: "Описание для Авито / Юлы / ВК / Яндекса", text: $description)

                        Text("Площадки публикации:")
                            .font(.system(size: 12, weight: .bold))
                            .foregroundColor(GarageTheme.textSecondary)

                        HStack(spacing: 8) {
                            ForEach(PlatformType.allCases) { pType in
                                let isActive = selectedPlatforms.contains(pType.rawValue)
                                Button {
                                    if isActive {
                                        selectedPlatforms.remove(pType.rawValue)
                                    } else {
                                        selectedPlatforms.insert(pType.rawValue)
                                    }
                                } label: {
                                    Text(pType.shortName)
                                        .font(.system(size: 11.5, weight: isActive ? .bold : .medium))
                                        .foregroundColor(isActive ? .white : GarageTheme.textSecondary)
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 8)
                                        .background(isActive ? GarageTheme.electricBlue : GarageTheme.cardBg)
                                        .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 10, style: .continuous)
                                                .stroke(isActive ? GarageTheme.electricBlue : GarageTheme.outline, lineWidth: 1)
                                        )
                                }
                                .buttonStyle(.plain)
                            }
                        }

                        if let onDelete = onDelete, let id = initialItem?.id {
                            Button {
                                onDelete(id)
                            } label: {
                                HStack(spacing: 6) {
                                    Image(systemName: "trash.fill")
                                    Text("Удалить товар со склада")
                                }
                                .font(.system(size: 13, weight: .bold))
                                .foregroundColor(GarageTheme.dangerRed)
                                .frame(maxWidth: .infinity)
                                .frame(height: 44)
                                .background(GarageTheme.dangerRed.opacity(0.14))
                                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                            }
                            .buttonStyle(.plain)
                            .padding(.top, 4)
                        }
                    }
                    .padding(.bottom, 20)
                }
            }
            .padding(.horizontal, 16)
        }
        .onChange(of: selectedItemPhoto) { newItem in
            Task {
                if let data = try? await newItem?.loadTransferable(type: Data.self),
                   let uiImage = UIImage(data: data),
                   let compressed = uiImage.jpegData(compressionQuality: 0.6) {
                    photoUri = "data:image/jpeg;base64," + compressed.base64EncodedString()
                }
            }
        }
        .onChange(of: selectedHintPhoto) { newItem in
            Task {
                if let data = try? await newItem?.loadTransferable(type: Data.self),
                   let uiImage = UIImage(data: data),
                   let compressed = uiImage.jpegData(compressionQuality: 0.6) {
                    hintPhotoUri = "data:image/jpeg;base64," + compressed.base64EncodedString()
                }
            }
        }
    }
}

struct PhotoHintSheet: View {
    let item: GarageItem
    let onDismiss: () -> Void
    let onUpdateHint: (GarageItem) -> Void

    @State private var hintNote: String
    @State private var shelfLocation: String
    @State private var hintPhotoUri: String
    @State private var isFlashlightBeaconOn: Bool = false
    @State private var selectedHintPhoto: PhotosPickerItem? = nil

    init(
        item: GarageItem,
        onDismiss: @escaping () -> Void,
        onUpdateHint: @escaping (GarageItem) -> Void
    ) {
        self.item = item
        self.onDismiss = onDismiss
        self.onUpdateHint = onUpdateHint
        _hintNote = State(initialValue: item.hintNote)
        _shelfLocation = State(initialValue: item.shelfLocation)
        _hintPhotoUri = State(initialValue: item.hintPhotoUri)
    }

    private func saveHint() {
        var copy = item
        copy.hintNote = hintNote.trimmingCharacters(in: .whitespacesAndNewlines)
        copy.shelfLocation = shelfLocation.trimmingCharacters(in: .whitespacesAndNewlines)
        copy.hintPhotoUri = hintPhotoUri
        onUpdateHint(copy)
    }

    var body: some View {
        ZStack {
            (isFlashlightBeaconOn ? Color.white : GarageTheme.surface)
                .ignoresSafeArea()

            VStack(spacing: 12) {
                CupertinoSheetHeader(
                    title: "Фото-подсказка места",
                    onCancel: onDismiss,
                    onDone: saveHint,
                    doneLabel: "Сохранить"
                )

                ScrollView {
                    VStack(alignment: .leading, spacing: 12) {
                        Text(item.title)
                            .font(.system(size: 16, weight: .bold, design: .rounded))
                            .foregroundColor(isFlashlightBeaconOn ? .black : GarageTheme.textPrimary)

                        // Flashlight Beacon Button for dark garage shelves
                        Button {
                            withAnimation {
                                isFlashlightBeaconOn.toggle()
                            }
                        } label: {
                            HStack(spacing: 8) {
                                Image(systemName: isFlashlightBeaconOn ? "sun.max.fill" : "flashlight.on.fill")
                                    .font(.system(size: 16, weight: .bold))
                                Text(isFlashlightBeaconOn
                                     ? "Выключить подсветку экрана (Маяк активен)"
                                     : "Подсветить экран (Фонарик для поиска в гараже)")
                                    .font(.system(size: 12.5, weight: .bold))
                            }
                            .foregroundColor(isFlashlightBeaconOn ? .white : GarageTheme.textPrimary)
                            .frame(maxWidth: .infinity)
                            .frame(height: 44)
                            .background(isFlashlightBeaconOn ? GarageTheme.orange : GarageTheme.cardBg)
                            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                            .overlay(
                                RoundedRectangle(cornerRadius: 12, style: .continuous)
                                    .stroke(GarageTheme.orange, lineWidth: 1)
                            )
                        }
                        .buttonStyle(.plain)

                        // Location & QR/Barcode Card
                        HStack {
                            VStack(alignment: .leading, spacing: 4) {
                                HStack(spacing: 5) {
                                    Image(systemName: "mappin.and.ellipse")
                                        .foregroundColor(GarageTheme.orange)
                                    Text("Зона: \(item.zone)")
                                        .font(.system(size: 13.5, weight: .bold))
                                        .foregroundColor(GarageTheme.orange)
                                }
                                Text("Полка: \(shelfLocation)")
                                    .font(.system(size: 13, weight: .semibold))
                                    .foregroundColor(GarageTheme.textPrimary)
                                Text("QR: \(item.qrCode) • Штрихкод: \(item.barcode.isEmpty ? "—" : item.barcode)")
                                    .font(.system(size: 11))
                                    .foregroundColor(GarageTheme.textSecondary)
                            }
                            Spacer()
                            VStack(spacing: 6) {
                                MiniQrCodeCanvas(code: item.qrCode, size: 42)
                                if !item.barcode.isEmpty {
                                    MiniBarcodeCanvas(code: item.barcode, width: 54, height: 18)
                                }
                            }
                        }
                        .padding(14)
                        .background(GarageTheme.cardBg)
                        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                        .overlay(
                            RoundedRectangle(cornerRadius: 14, style: .continuous)
                                .stroke(GarageTheme.orange.opacity(0.6), lineWidth: 1)
                        )

                        // Shelf photo box
                        ItemThumbnailBox(
                            photoUri: hintPhotoUri.isEmpty ? item.photoUri : hintPhotoUri,
                            title: "Стеллаж: \(shelfLocation)",
                            height: 155,
                            cornerRadius: 14
                        )

                        PhotosPicker(selection: $selectedHintPhoto, matching: .images) {
                            HStack(spacing: 6) {
                                Image(systemName: "camera.fill")
                                    .foregroundColor(GarageTheme.electricBlue)
                                Text("Прикрепить фото полки / коробки из галереи iPhone")
                                    .font(.system(size: 12.5, weight: .bold))
                                    .foregroundColor(GarageTheme.textPrimary)
                            }
                            .frame(maxWidth: .infinity)
                            .frame(height: 44)
                            .background(GarageTheme.cardBg)
                            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                            .overlay(
                                RoundedRectangle(cornerRadius: 12, style: .continuous)
                                    .stroke(GarageTheme.outline, lineWidth: 1)
                            )
                        }
                        .buttonStyle(.plain)

                        GarageFieldBox(label: "Точный стеллаж / полка / ряд", text: $shelfLocation)
                        GarageFieldBox(label: "Ориентир (чтобы найти за 5 секунд)", text: $hintNote)
                    }
                    .padding(.bottom, 20)
                }
            }
            .padding(.horizontal, 16)
        }
        .onChange(of: selectedHintPhoto) { newItem in
            Task {
                if let data = try? await newItem?.loadTransferable(type: Data.self),
                   let uiImage = UIImage(data: data),
                   let compressed = uiImage.jpegData(compressionQuality: 0.6) {
                    hintPhotoUri = "data:image/jpeg;base64," + compressed.base64EncodedString()
                }
            }
        }
    }
}

struct PlatformConnectionSheet: View {
    let platformType: PlatformType
    let existingConnection: PlatformConnection?
    let onDismiss: () -> Void
    let onSave: (PlatformConnection) -> Void

    @State private var isConnected: Bool
    @State private var isSelectedForUpload: Bool
    @State private var accountIdentifier: String
    @State private var apiClientId: String
    @State private var defaultPhone: String
    @State private var defaultCity: String
    @State private var autoSync: Bool
    @State private var autoPromote: Bool

    init(
        platformType: PlatformType,
        existingConnection: PlatformConnection?,
        onDismiss: @escaping () -> Void,
        onSave: @escaping (PlatformConnection) -> Void
    ) {
        self.platformType = platformType
        self.existingConnection = existingConnection
        self.onDismiss = onDismiss
        self.onSave = onSave

        _isConnected = State(initialValue: existingConnection?.isConnected ?? true)
        _isSelectedForUpload = State(initialValue: existingConnection?.isSelectedForUpload ?? true)
        _accountIdentifier = State(initialValue: existingConnection?.accountIdentifier ?? "Профиль Магазина #\(platformType.shortName)")
        _apiClientId = State(initialValue: existingConnection?.apiClientId ?? "api_\(platformType.rawValue)_live_token")
        _defaultPhone = State(initialValue: existingConnection?.defaultContactPhone ?? "+7 (999) 000-00-00")
        _defaultCity = State(initialValue: existingConnection?.defaultCityAddress ?? "Москва, Гаражный кооператив")
        _autoSync = State(initialValue: existingConnection?.autoSync ?? true)
        _autoPromote = State(initialValue: existingConnection?.autoPromote ?? false)
    }

    private func saveConn() {
        let updated = PlatformConnection(
            id: platformType.rawValue,
            userId: existingConnection?.userId ?? "",
            platformKey: platformType.rawValue,
            platformName: platformType.displayName,
            isConnected: isConnected,
            isSelectedForUpload: isSelectedForUpload,
            accountIdentifier: accountIdentifier.trimmingCharacters(in: .whitespacesAndNewlines),
            apiClientId: apiClientId.trimmingCharacters(in: .whitespacesAndNewlines),
            autoSync: autoSync,
            autoPromote: autoPromote,
            defaultContactPhone: defaultPhone.trimmingCharacters(in: .whitespacesAndNewlines),
            defaultCityAddress: defaultCity.trimmingCharacters(in: .whitespacesAndNewlines),
            syncedCount: existingConnection?.syncedCount ?? 6,
            lastSyncStatus: isConnected ? "Синхронизация активна • Ошибок нет" : "Отключено пользователем"
        )
        onSave(updated)
    }

    var body: some View {
        ZStack {
            GarageTheme.surface
                .ignoresSafeArea()

            VStack(spacing: 12) {
                CupertinoSheetHeader(
                    title: platformType.displayName,
                    onCancel: onDismiss,
                    onDone: saveConn,
                    doneLabel: "Готово"
                )

                ScrollView {
                    VStack(alignment: .leading, spacing: 12) {
                        HStack(spacing: 12) {
                            PlatformBadgeIcon(
                                platformType: platformType,
                                size: 46,
                                showStatusDot: true,
                                isConnected: isConnected
                            )
                            VStack(alignment: .leading, spacing: 2) {
                                Text("Настройка \(platformType.displayName)")
                                    .font(.system(size: 16, weight: .bold, design: .rounded))
                                    .foregroundColor(GarageTheme.textPrimary)
                                Text(platformType.apiPortalHint)
                                    .font(.system(size: 12))
                                    .foregroundColor(GarageTheme.textSecondary)
                            }
                        }

                        VStack(spacing: 10) {
                            Toggle("Площадка подключена и активна", isOn: $isConnected)
                                .tint(GarageTheme.emeraldGreen)
                                .font(.system(size: 13.5, weight: .bold))
                                .foregroundColor(GarageTheme.textPrimary)

                            Divider().background(GarageTheme.outline)

                            Toggle("Включать в «Публикацию в 1 клик»", isOn: $isSelectedForUpload)
                                .tint(GarageTheme.electricBlue)
                                .font(.system(size: 13))
                                .foregroundColor(GarageTheme.textPrimary)

                            Divider().background(GarageTheme.outline)

                            Toggle("Авто-синхронизация цен и остатков", isOn: $autoSync)
                                .tint(GarageTheme.emeraldGreen)
                                .font(.system(size: 13))
                                .foregroundColor(GarageTheme.textPrimary)

                            Divider().background(GarageTheme.outline)

                            Toggle("Авто-поднятие объявлений (Продвижение)", isOn: $autoPromote)
                                .tint(GarageTheme.orange)
                                .font(.system(size: 13))
                                .foregroundColor(GarageTheme.textPrimary)
                        }
                        .padding(14)
                        .background(GarageTheme.cardBg)
                        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                        .overlay(
                            RoundedRectangle(cornerRadius: 14, style: .continuous)
                                .stroke(GarageTheme.outline, lineWidth: 1)
                        )

                        GarageFieldBox(label: "Аккаунт / ID магазина на площадке", text: $accountIdentifier)
                        GarageFieldBox(label: "API Ключ / Токен автовыгрузки", text: $apiClientId)
                        GarageFieldBox(label: "Телефон для связи в объявлениях", text: $defaultPhone)
                        GarageFieldBox(label: "Адрес самовывоза (Гараж / Склад)", text: $defaultCity)
                    }
                    .padding(.bottom, 20)
                }
            }
            .padding(.horizontal, 16)
        }
    }
}

struct QrScannerSheet: View {
    let items: [GarageItem]
    let onDismiss: () -> Void
    let onSelectItem: (GarageItem) -> Void
    let onCreateNewWithCode: (String) -> Void

    @State private var codeQuery: String = ""

    private var matchedItems: [GarageItem] {
        if codeQuery.trimmingCharacters(in: .whitespaces).isEmpty {
            return Array(items.prefix(4))
        }
        return items.filter {
            $0.qrCode.localizedCaseInsensitiveContains(codeQuery) ||
            $0.barcode.localizedCaseInsensitiveContains(codeQuery) ||
            $0.serialCode.localizedCaseInsensitiveContains(codeQuery) ||
            $0.title.localizedCaseInsensitiveContains(codeQuery) ||
            $0.shelfLocation.localizedCaseInsensitiveContains(codeQuery)
        }
    }

    var body: some View {
        ZStack {
            GarageTheme.surface
                .ignoresSafeArea()

            VStack(spacing: 12) {
                CupertinoSheetHeader(
                    title: "Сканер QR и Штрихкодов",
                    onCancel: onDismiss
                )

                ScrollView {
                    VStack(alignment: .leading, spacing: 12) {
                        // Simulated Camera Viewfinder Box
                        ZStack {
                            RoundedRectangle(cornerRadius: 16, style: .continuous)
                                .fill(GarageTheme.background)
                                .frame(height: 120)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                                        .stroke(GarageTheme.electricBlue, lineWidth: 1.5)
                                )

                            VStack(spacing: 6) {
                                Image(systemName: "qrcode.viewfinder")
                                    .font(.system(size: 38, weight: .bold))
                                    .foregroundColor(GarageTheme.electricBlue)
                                Text("Наведите на стикер полки или введите цифры кода ниже")
                                    .font(.system(size: 11.5))
                                    .foregroundColor(GarageTheme.textSecondary)
                            }
                        }

                        GarageFieldBox(label: "Код (например: 8842, 4607112884210 или название)", text: $codeQuery)

                        // Printable Sticker Preview for first matched item
                        if let first = matchedItems.first {
                            VStack(alignment: .leading, spacing: 8) {
                                HStack {
                                    Text("ПЕЧАТНЫЙ СТИКЕР ПОЛКИ")
                                        .font(.system(size: 11, weight: .heavy, design: .rounded))
                                        .foregroundColor(GarageTheme.orange)
                                    Spacer()
                                    ShareLink(
                                        item: "СТИКЕР ГАРАЖА: \(first.title)\nЗона: \(first.zone), \(first.shelfLocation)\nQR: \(first.qrCode) | EAN: \(first.barcode)"
                                    ) {
                                        HStack(spacing: 4) {
                                            Image(systemName: "printer.fill")
                                            Text("Печать / Поделиться")
                                        }
                                        .font(.system(size: 11, weight: .bold))
                                        .foregroundColor(GarageTheme.electricBlue)
                                    }
                                    .buttonStyle(.plain)
                                }

                                HStack {
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(first.title)
                                            .font(.system(size: 13, weight: .bold))
                                            .foregroundColor(GarageTheme.textPrimary)
                                            .lineLimit(1)
                                        Text("\(first.zone) • \(first.shelfLocation)")
                                            .font(.system(size: 11, weight: .semibold))
                                            .foregroundColor(GarageTheme.emeraldGreen)
                                        Text("QR: \(first.qrCode) | \(first.barcode)")
                                            .font(.system(size: 10))
                                            .foregroundColor(GarageTheme.textSecondary)
                                    }
                                    Spacer()
                                    MiniQrCodeCanvas(code: first.qrCode, size: 36)
                                }
                            }
                            .padding(12)
                            .background(GarageTheme.cardBg)
                            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                            .overlay(
                                RoundedRectangle(cornerRadius: 14, style: .continuous)
                                    .stroke(GarageTheme.outline, lineWidth: 1)
                            )
                        }

                        Text("Найденные позиции на складе:")
                            .font(.system(size: 12, weight: .bold))
                            .foregroundColor(GarageTheme.textSecondary)

                        ForEach(matchedItems) { item in
                            Button {
                                onSelectItem(item)
                            } label: {
                                HStack {
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(item.title)
                                            .font(.system(size: 13.5, weight: .bold, design: .rounded))
                                            .foregroundColor(GarageTheme.textPrimary)
                                        Text("📍 \(item.zone), \(item.shelfLocation)")
                                            .font(.system(size: 11.5, weight: .semibold))
                                            .foregroundColor(GarageTheme.orange)
                                        Text("QR: \(item.qrCode) | Штрихкод: \(item.barcode)")
                                            .font(.system(size: 10.5))
                                            .foregroundColor(GarageTheme.textSecondary)
                                    }
                                    Spacer()
                                    MiniQrCodeCanvas(code: item.qrCode, size: 28)
                                }
                                .padding(12)
                                .background(GarageTheme.cardBg)
                                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                                        .stroke(GarageTheme.outline, lineWidth: 1)
                                )
                            }
                            .buttonStyle(.plain)
                        }

                        Button {
                            let newCode = codeQuery.trimmingCharacters(in: .whitespaces).isEmpty
                                ? GarageRepository.generateQrCode()
                                : codeQuery.trimmingCharacters(in: .whitespaces)
                            onCreateNewWithCode(newCode)
                        } label: {
                            HStack(spacing: 6) {
                                Image(systemName: "plus.circle.fill")
                                Text("Создать новый товар с этим кодом")
                            }
                            .font(.system(size: 13.5, weight: .bold))
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .frame(height: 48)
                            .background(GarageTheme.orange)
                            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                        }
                        .buttonStyle(.plain)
                    }
                    .padding(.bottom, 20)
                }
            }
            .padding(.horizontal, 16)
        }
    }
}

struct CreateBuyerDialogSheet: View {
    let items: [GarageItem]
    let onDismiss: () -> Void
    let onCreate: (BuyerDialog) -> Void

    @State private var buyerName: String = ""
    @State private var messageText: String = ""
    @State private var selectedPlatform: PlatformType = .avito
    @State private var selectedItemIndex: Int = 0

    private func createAction() {
        let chosenItem = items.indices.contains(selectedItemIndex) ? items[selectedItemIndex] : nil
        let finalBuyer = buyerName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            ? "Покупатель (\(selectedPlatform.shortName))"
            : buyerName.trimmingCharacters(in: .whitespacesAndNewlines)
        let finalMsg = messageText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            ? "Здравствуйте! Товар ещё в наличии?"
            : messageText.trimmingCharacters(in: .whitespacesAndNewlines)

        let dialog = BuyerDialog(
            buyerName: finalBuyer,
            platformKey: selectedPlatform.rawValue,
            itemId: chosenItem?.id ?? "",
            itemTitle: chosenItem?.title ?? "Товар со склада",
            itemPrice: chosenItem?.price ?? 0,
            itemShelfLocation: chosenItem != nil ? "\(chosenItem!.zone), \(chosenItem!.shelfLocation)" : "Гараж, Стеллаж 1",
            itemQrCode: chosenItem?.qrCode ?? "#8842",
            lastMessage: finalMsg,
            timeLabel: "Сейчас",
            unreadCount: 1
        )
        onCreate(dialog)
    }

    var body: some View {
        ZStack {
            GarageTheme.surface
                .ignoresSafeArea()

            VStack(spacing: 12) {
                CupertinoSheetHeader(
                    title: "Новый диалог с площадки",
                    onCancel: onDismiss,
                    onDone: createAction,
                    doneLabel: "Создать"
                )

                ScrollView {
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Площадка обращения:")
                            .font(.system(size: 12, weight: .bold))
                            .foregroundColor(GarageTheme.textSecondary)

                        HStack(spacing: 8) {
                            ForEach(PlatformType.allCases) { pType in
                                let isSel = selectedPlatform == pType
                                Button {
                                    selectedPlatform = pType
                                } label: {
                                    Text(pType.shortName)
                                        .font(.system(size: 12, weight: isSel ? .bold : .medium))
                                        .foregroundColor(isSel ? .white : GarageTheme.textSecondary)
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 8)
                                        .background(isSel ? GarageTheme.orange : GarageTheme.cardBg)
                                        .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 10, style: .continuous)
                                                .stroke(isSel ? GarageTheme.orange : GarageTheme.outline, lineWidth: 1)
                                        )
                                }
                                .buttonStyle(.plain)
                            }
                        }

                        if !items.isEmpty {
                            Text("По какому товару вопрос:")
                                .font(.system(size: 12, weight: .bold))
                                .foregroundColor(GarageTheme.textSecondary)

                            ScrollView(.horizontal, showsIndicators: false) {
                                HStack(spacing: 8) {
                                    ForEach(Array(items.prefix(8).enumerated()), id: \.element.id) { index, item in
                                        let isSel = selectedItemIndex == index
                                        Button {
                                            selectedItemIndex = index
                                        } label: {
                                            Text(String(item.title.prefix(22)))
                                                .font(.system(size: 11.5, weight: isSel ? .bold : .medium))
                                                .foregroundColor(isSel ? .white : GarageTheme.textSecondary)
                                                .padding(.horizontal, 12)
                                                .padding(.vertical, 8)
                                                .background(isSel ? GarageTheme.electricBlue : GarageTheme.cardBg)
                                                .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                                                .overlay(
                                                    RoundedRectangle(cornerRadius: 10, style: .continuous)
                                                        .stroke(isSel ? GarageTheme.electricBlue : GarageTheme.outline, lineWidth: 1)
                                                )
                                        }
                                        .buttonStyle(.plain)
                                    }
                                }
                            }
                        }

                        GarageFieldBox(label: "Имя покупателя", text: $buyerName)
                        GarageFieldBox(label: "Сообщение покупателя", text: $messageText)
                    }
                    .padding(.bottom, 20)
                }
            }
            .padding(.horizontal, 16)
        }
    }
}

struct PromotionBoostSheet: View {
    let items: [GarageItem]
    let onDismiss: () -> Void
    let onBoostItem: (GarageItem) -> Void

    var body: some View {
        ZStack {
            GarageTheme.surface
                .ignoresSafeArea()

            VStack(spacing: 12) {
                CupertinoSheetHeader(
                    title: "Продвижение и статистика",
                    onCancel: onDismiss
                )

                Text("Бесплатное поднятие приоритета выдачи и обновление фида на Авито, Юле, ВК и Яндексе:")
                    .font(.system(size: 12))
                    .foregroundColor(GarageTheme.textSecondary)
                    .frame(maxWidth: .infinity, alignment: .leading)

                ScrollView {
                    VStack(spacing: 10) {
                        ForEach(items) { item in
                            HStack(spacing: 10) {
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(item.title)
                                        .font(.system(size: 13.5, weight: .bold, design: .rounded))
                                        .foregroundColor(GarageTheme.textPrimary)
                                        .lineLimit(1)
                                    Text("👁 Просмотров: \(item.viewsCount) • 💬 Запросов: \(item.inquiriesCount)")
                                        .font(.system(size: 11.5, weight: .semibold))
                                        .foregroundColor(GarageTheme.emeraldGreen)
                                }

                                Spacer()

                                Button {
                                    onBoostItem(item)
                                } label: {
                                    HStack(spacing: 4) {
                                        Image(systemName: "bolt.fill")
                                            .font(.system(size: 12))
                                        Text("Поднять")
                                            .font(.system(size: 12, weight: .bold))
                                    }
                                    .foregroundColor(.white)
                                    .padding(.horizontal, 12)
                                    .padding(.vertical, 8)
                                    .background(GarageTheme.orange)
                                    .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                                }
                                .buttonStyle(.plain)
                            }
                            .padding(12)
                            .background(GarageTheme.cardBg)
                            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                            .overlay(
                                RoundedRectangle(cornerRadius: 14, style: .continuous)
                                    .stroke(GarageTheme.outline, lineWidth: 1)
                            )
                        }
                    }
                    .padding(.bottom, 20)
                }
            }
            .padding(.horizontal, 16)
        }
    }
}

private struct GarageFieldBox: View {
    let label: String
    @Binding var text: String
    var keyboard: UIKeyboardType = .default

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(label)
                .font(.system(size: 11, weight: .semibold))
                .foregroundColor(GarageTheme.textSecondary)

            TextField(label, text: $text)
                .font(.system(size: 13.5))
                .foregroundColor(GarageTheme.textPrimary)
                .keyboardType(keyboard)
                .autocorrectionDisabled()
                .padding(.horizontal, 12)
                .frame(height: 44)
                .background(GarageTheme.cardBg)
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                        .stroke(GarageTheme.outline, lineWidth: 1)
                )
        }
    }
}
