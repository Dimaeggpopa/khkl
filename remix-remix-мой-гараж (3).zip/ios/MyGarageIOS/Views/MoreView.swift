import SwiftUI

struct MoreView: View {
    @ObservedObject var viewModel: GarageViewModel
    let userEmail: String
    let onOpenPlatformSettings: (PlatformType) -> Void
    let onOpenPhotoHint: (GarageItem) -> Void
    let onSignOut: () -> Void

    @State private var newZoneName: String = ""
    @State private var newZoneCapacity: String = "40"
    @State private var newZoneDescription: String = ""
    @State private var newTemplateText: String = ""
    @State private var emergencyQuery: String = ""

    private var totalWarehouseValue: Int64 {
        viewModel.items.reduce(0) { $0 + ($1.price * $1.quantity) }
    }

    private var publishedEverywhereCount: Int {
        viewModel.items.filter { $0.publishedPlatforms.count >= 4 }.count
    }

    private var verifiedCount: Int {
        viewModel.items.filter(\.isVerifiedInInventory).count
    }

    private var emergencyMatchedItems: [GarageItem] {
        guard !emergencyQuery.trimmingCharacters(in: .whitespaces).isEmpty else { return [] }
        return viewModel.items.filter {
            $0.title.localizedCaseInsensitiveContains(emergencyQuery) ||
            $0.qrCode.localizedCaseInsensitiveContains(emergencyQuery) ||
            $0.barcode.localizedCaseInsensitiveContains(emergencyQuery) ||
            $0.shelfLocation.localizedCaseInsensitiveContains(emergencyQuery)
        }
    }

    private var csvExportString: String {
        var rows = ["Название;Цена (₽);Кол-во;Зона;Полка;QR-код;Штрихкод;Площадки"]
        for item in viewModel.items {
            rows.append("\(item.title);\(item.price);\(item.quantity);\(item.zone);\(item.shelfLocation);\(item.qrCode);\(item.barcode);\(item.publishedPlatforms.joined(separator: ","))")
        }
        return rows.joined(separator: "\n")
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                Text("ЕЩЁ • НАСТРОЙКИ И ИНСТРУМЕНТЫ ГАРАЖА")
                    .font(.system(size: 15, weight: .bold, design: .rounded))
                    .foregroundColor(GarageTheme.textPrimary)
                    .padding(.top, 4)

                // 1. Theme & Accent Card
                VStack(alignment: .leading, spacing: 10) {
                    HStack(spacing: 8) {
                        Image(systemName: "paintbrush.pointed.fill")
                            .foregroundColor(GarageTheme.electricBlue)
                        VStack(alignment: .leading, spacing: 1) {
                            Text("Внешний вид и тема оформления")
                                .font(.system(size: 14, weight: .bold, design: .rounded))
                                .foregroundColor(GarageTheme.textPrimary)
                            Text("Нативная адаптация под iOS и освещение в гараже")
                                .font(.system(size: 11))
                                .foregroundColor(GarageTheme.textSecondary)
                        }
                    }

                    // Cupertino Segmented Theme Switcher
                    HStack(spacing: 4) {
                        ForEach(AppThemeMode.allCases) { mode in
                            let selected = viewModel.themeMode == mode
                            Button {
                                viewModel.themeMode = mode
                            } label: {
                                Text(mode.label)
                                    .font(.system(size: 11, weight: selected ? .bold : .medium))
                                    .foregroundColor(selected ? .white : GarageTheme.textSecondary)
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 8)
                                    .background(selected ? GarageTheme.orange : Color.clear)
                                    .clipShape(RoundedRectangle(cornerRadius: 9, style: .continuous))
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(4)
                    .background(GarageTheme.background)
                    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))

                    Text("Акцентная палитра кнопок:")
                        .font(.system(size: 11, weight: .semibold))
                        .foregroundColor(GarageTheme.textSecondary)

                    HStack(spacing: 8) {
                        ForEach(AppAccentPalette.allCases) { palette in
                            let isSelected = viewModel.accentPalette == palette
                            Button {
                                viewModel.accentPalette = palette
                            } label: {
                                Text(palette.label)
                                    .font(.system(size: 10, weight: isSelected ? .bold : .medium))
                                    .foregroundColor(GarageTheme.textPrimary)
                                    .multilineTextAlignment(.center)
                                    .lineLimit(2)
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 8)
                                    .padding(.horizontal, 4)
                                    .background(isSelected ? GarageTheme.orange.opacity(0.18) : GarageTheme.background)
                                    .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 10, style: .continuous)
                                            .stroke(isSelected ? GarageTheme.orange : GarageTheme.outline, lineWidth: isSelected ? 1.5 : 1)
                                    )
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
                .padding(14)
                .background(GarageTheme.cardBg)
                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                        .stroke(GarageTheme.outline, lineWidth: 1)
                )

                // 2. Emergency Shelf Radar
                VStack(alignment: .leading, spacing: 8) {
                    HStack(spacing: 8) {
                        Image(systemName: "flashlight.on.fill")
                            .foregroundColor(GarageTheme.orange)
                        VStack(alignment: .leading, spacing: 1) {
                            Text("Экстренный радар полки (когда покупатель ждёт)")
                                .font(.system(size: 13.5, weight: .bold, design: .rounded))
                                .foregroundColor(GarageTheme.textPrimary)
                            Text("Мгновенно показывает зону, стеллаж и фото-подсказку по 2 буквам")
                                .font(.system(size: 11))
                                .foregroundColor(GarageTheme.textSecondary)
                        }
                    }

                    HStack(spacing: 8) {
                        Image(systemName: "magnifyingglass")
                            .foregroundColor(GarageTheme.orange)
                        TextField("Введите деталь или QR (например: шины, перфоратор, 8842)...", text: $emergencyQuery)
                            .font(.system(size: 13))
                            .foregroundColor(GarageTheme.textPrimary)
                            .autocorrectionDisabled()
                    }
                    .padding(.horizontal, 12)
                    .frame(height: 44)
                    .background(GarageTheme.background)
                    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .stroke(GarageTheme.outline, lineWidth: 1)
                    )

                    ForEach(emergencyMatchedItems.prefix(3)) { item in
                        HStack {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(item.title)
                                    .font(.system(size: 12.5, weight: .bold, design: .rounded))
                                    .foregroundColor(GarageTheme.textPrimary)
                                Text("📍 \(item.zone) • \(item.shelfLocation) | QR: \(item.qrCode)")
                                    .font(.system(size: 11, weight: .semibold))
                                    .foregroundColor(GarageTheme.emeraldGreen)
                            }
                            Spacer()
                            PhotoHintChip(label: "Открыть полку") {
                                onOpenPhotoHint(item)
                            }
                        }
                        .padding(10)
                        .background(GarageTheme.background)
                        .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                    }
                }
                .padding(14)
                .background(GarageTheme.cardBg)
                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                        .stroke(GarageTheme.orange.opacity(0.45), lineWidth: 1)
                )

                // 3. Financial Analytics & Export
                VStack(alignment: .leading, spacing: 10) {
                    Text("Финансовая сводка склада (Бесплатно • Без лимитов)")
                        .font(.system(size: 14, weight: .bold, design: .rounded))
                        .foregroundColor(GarageTheme.textPrimary)

                    HStack(spacing: 10) {
                        StatMiniCardIOS(
                            label: "Стоимость склада",
                            value: formatRubles(totalWarehouseValue),
                            valueColor: GarageTheme.emeraldGreen
                        )
                        StatMiniCardIOS(
                            label: "Везде размещено",
                            value: "\(publishedEverywhereCount) из \(viewModel.items.count)",
                            valueColor: GarageTheme.electricBlue
                        )
                        StatMiniCardIOS(
                            label: "Проверено на полках",
                            value: "\(verifiedCount) шт.",
                            valueColor: GarageTheme.orange
                        )
                    }

                    ShareLink(item: csvExportString) {
                        HStack(spacing: 6) {
                            Image(systemName: "square.and.arrow.up")
                                .font(.system(size: 14, weight: .bold))
                                .foregroundColor(GarageTheme.electricBlue)
                            Text("Экспортировать ведомость склада (CSV / Текст)")
                                .font(.system(size: 12.5, weight: .bold))
                                .foregroundColor(GarageTheme.textPrimary)
                        }
                        .frame(maxWidth: .infinity)
                        .frame(height: 44)
                        .background(GarageTheme.background)
                        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                        .overlay(
                            RoundedRectangle(cornerRadius: 12, style: .continuous)
                                .stroke(GarageTheme.outline, lineWidth: 1)
                        )
                    }
                    .buttonStyle(.plain)
                }
                .padding(14)
                .background(GarageTheme.cardBg)
                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                        .stroke(GarageTheme.outline, lineWidth: 1)
                )

                // 4. Storage Zones Constructor
                VStack(alignment: .leading, spacing: 8) {
                    Text("Конструктор мест хранения (Полки, Стеллажи, Ангары)")
                        .font(.system(size: 14, weight: .bold, design: .rounded))
                        .foregroundColor(GarageTheme.textPrimary)

                    ForEach(viewModel.zones) { zone in
                        HStack {
                            Image(systemName: "mappin.and.ellipse")
                                .font(.system(size: 14))
                                .foregroundColor(GarageTheme.orange)
                            VStack(alignment: .leading, spacing: 1) {
                                Text("\(zone.name) (вместимость: \(zone.capacity) мест)")
                                    .font(.system(size: 12.5, weight: .bold))
                                    .foregroundColor(GarageTheme.textPrimary)
                                if !zone.description.isEmpty {
                                    Text(zone.description)
                                        .font(.system(size: 11))
                                        .foregroundColor(GarageTheme.textSecondary)
                                }
                            }
                            Spacer()
                            Button {
                                viewModel.deleteStorageZone(zoneId: zone.id)
                            } label: {
                                Image(systemName: "trash")
                                    .font(.system(size: 14))
                                    .foregroundColor(GarageTheme.textSecondary)
                            }
                            .buttonStyle(.plain)
                        }
                        .padding(.vertical, 3)
                    }

                    HStack(spacing: 8) {
                        TextField("Новая зона (напр. Подвал B)", text: $newZoneName)
                            .font(.system(size: 12.5))
                            .foregroundColor(GarageTheme.textPrimary)
                            .padding(.horizontal, 10)
                            .frame(height: 40)
                            .background(GarageTheme.background)
                            .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                            .overlay(
                                RoundedRectangle(cornerRadius: 10, style: .continuous)
                                    .stroke(GarageTheme.outline, lineWidth: 1)
                            )

                        TextField("Мест", text: $newZoneCapacity)
                            .font(.system(size: 12.5))
                            .foregroundColor(GarageTheme.textPrimary)
                            .keyboardType(.numberPad)
                            .padding(.horizontal, 10)
                            .frame(width: 78, height: 40)
                            .background(GarageTheme.background)
                            .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                            .overlay(
                                RoundedRectangle(cornerRadius: 10, style: .continuous)
                                    .stroke(GarageTheme.outline, lineWidth: 1)
                            )
                    }

                    HStack(spacing: 8) {
                        TextField("Ориентир (напр. У дальней стены слева)", text: $newZoneDescription)
                            .font(.system(size: 12.5))
                            .foregroundColor(GarageTheme.textPrimary)
                            .padding(.horizontal, 10)
                            .frame(height: 40)
                            .background(GarageTheme.background)
                            .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                            .overlay(
                                RoundedRectangle(cornerRadius: 10, style: .continuous)
                                    .stroke(GarageTheme.outline, lineWidth: 1)
                            )

                        Button {
                            let clean = newZoneName.trimmingCharacters(in: .whitespacesAndNewlines)
                            guard !clean.isEmpty else { return }
                            viewModel.saveStorageZone(
                                name: clean,
                                capacity: Int64(newZoneCapacity) ?? 40,
                                description: newZoneDescription.trimmingCharacters(in: .whitespacesAndNewlines)
                            )
                            newZoneName = ""
                            newZoneDescription = ""
                        } label: {
                            HStack(spacing: 4) {
                                Image(systemName: "plus")
                                Text("Зона")
                            }
                            .font(.system(size: 12, weight: .bold))
                            .foregroundColor(.white)
                            .padding(.horizontal, 14)
                            .frame(height: 40)
                            .background(GarageTheme.orange)
                            .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(14)
                .background(GarageTheme.cardBg)
                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                        .stroke(GarageTheme.outline, lineWidth: 1)
                )

                // 5. Connected Marketplaces & API
                VStack(alignment: .leading, spacing: 8) {
                    Text("Интеграции с площадками (Авито, Юла, ВК, Яндекс)")
                        .font(.system(size: 14, weight: .bold, design: .rounded))
                        .foregroundColor(GarageTheme.textPrimary)

                    ForEach(PlatformType.allCases) { pType in
                        let conn = viewModel.platforms.first(where: { $0.platformKey == pType.rawValue })
                        HStack(spacing: 10) {
                            PlatformBadgeIcon(
                                platformType: pType,
                                size: 36,
                                showStatusDot: true,
                                isConnected: conn?.isConnected ?? true
                            )

                            VStack(alignment: .leading, spacing: 2) {
                                Text(pType.displayName)
                                    .font(.system(size: 13, weight: .bold, design: .rounded))
                                    .foregroundColor(GarageTheme.textPrimary)
                                Text(conn?.lastSyncStatus ?? "Подключено • Готово к публикации")
                                    .font(.system(size: 11))
                                    .foregroundColor(GarageTheme.textSecondary)
                                    .lineLimit(1)
                            }

                            Spacer()

                            Button {
                                onOpenPlatformSettings(pType)
                            } label: {
                                Text("Настроить")
                                    .font(.system(size: 11.5, weight: .bold))
                                    .foregroundColor(GarageTheme.textPrimary)
                                    .padding(.horizontal, 12)
                                    .padding(.vertical, 6)
                                    .background(GarageTheme.background)
                                    .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 10, style: .continuous)
                                            .stroke(GarageTheme.outline, lineWidth: 1)
                                    )
                            }
                            .buttonStyle(.plain)
                        }
                        .padding(.vertical, 3)
                    }
                }
                .padding(14)
                .background(GarageTheme.cardBg)
                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                        .stroke(GarageTheme.outline, lineWidth: 1)
                )

                // 6. Quick Reply Templates Manager
                VStack(alignment: .leading, spacing: 8) {
                    Text("Шаблоны быстрых ответов покупателям")
                        .font(.system(size: 14, weight: .bold, design: .rounded))
                        .foregroundColor(GarageTheme.textPrimary)

                    ForEach(viewModel.quickReplyTemplates, id: \.self) { tpl in
                        HStack {
                            Text("• \(tpl)")
                                .font(.system(size: 12))
                                .foregroundColor(GarageTheme.textPrimary)
                            Spacer()
                            Button {
                                viewModel.removeQuickReplyTemplate(tpl)
                            } label: {
                                Image(systemName: "trash")
                                    .font(.system(size: 13))
                                    .foregroundColor(GarageTheme.textSecondary)
                            }
                            .buttonStyle(.plain)
                        }
                        .padding(.vertical, 2)
                    }

                    HStack(spacing: 8) {
                        TextField("Добавить свой быстрый ответ...", text: $newTemplateText)
                            .font(.system(size: 12.5))
                            .foregroundColor(GarageTheme.textPrimary)
                            .padding(.horizontal, 10)
                            .frame(height: 40)
                            .background(GarageTheme.background)
                            .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                            .overlay(
                                RoundedRectangle(cornerRadius: 10, style: .continuous)
                                    .stroke(GarageTheme.outline, lineWidth: 1)
                            )

                        Button {
                            let clean = newTemplateText.trimmingCharacters(in: .whitespacesAndNewlines)
                            guard !clean.isEmpty else { return }
                            viewModel.addQuickReplyTemplate(clean)
                            newTemplateText = ""
                        } label: {
                            Image(systemName: "plus")
                                .font(.system(size: 15, weight: .bold))
                                .foregroundColor(.white)
                                .frame(width: 44, height: 40)
                                .background(GarageTheme.orange)
                                .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(14)
                .background(GarageTheme.cardBg)
                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                        .stroke(GarageTheme.outline, lineWidth: 1)
                )

                // 7. Account & Sign Out
                HStack {
                    HStack(spacing: 10) {
                        Image(systemName: "checkmark.shield.fill")
                            .font(.system(size: 20))
                            .foregroundColor(GarageTheme.emeraldGreen)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(userEmail)
                                .font(.system(size: 13, weight: .bold))
                                .foregroundColor(GarageTheme.textPrimary)
                            Text("Полная версия iOS • Все функции бесплатны")
                                .font(.system(size: 11))
                                .foregroundColor(GarageTheme.emeraldGreen)
                        }
                    }

                    Spacer()

                    Button(action: onSignOut) {
                        HStack(spacing: 4) {
                            Image(systemName: "rectangle.portrait.and.arrow.right")
                                .font(.system(size: 13, weight: .bold))
                            Text("Выйти")
                                .font(.system(size: 12, weight: .bold))
                        }
                        .foregroundColor(GarageTheme.dangerRed)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 8)
                        .background(GarageTheme.dangerRed.opacity(0.14))
                        .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                    }
                    .buttonStyle(.plain)
                }
                .padding(14)
                .background(GarageTheme.cardBg)
                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                        .stroke(GarageTheme.outline, lineWidth: 1)
                )
            }
            .padding(.horizontal, 16)
            .padding(.top, 8)
            .padding(.bottom, 24)
        }
    }
}

private struct StatMiniCardIOS: View {
    let label: String
    let value: String
    let valueColor: Color

    var body: some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(label)
                .font(.system(size: 10))
                .foregroundColor(GarageTheme.textSecondary)
                .lineLimit(1)
            Text(value)
                .font(.system(size: 12.5, weight: .heavy, design: .rounded))
                .foregroundColor(valueColor)
                .lineLimit(1)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(10)
        .background(GarageTheme.background)
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 12, style: .continuous)
                .stroke(GarageTheme.outline, lineWidth: 1)
        )
    }
}
