import SwiftUI

struct WarehouseView: View {
    @ObservedObject var viewModel: GarageViewModel
    let onAddItem: () -> Void
    let onEditItem: (GarageItem) -> Void
    let onOpenPhotoHint: (GarageItem) -> Void
    let onOpenQrScanner: () -> Void

    @State private var searchQuery: String = ""
    @State private var selectedZone: String = "Все места"
    @State private var isInventoryAuditMode: Bool = false
    @State private var sortByPriceDesc: Bool = false

    private var zoneFilters: [String] {
        var base = ["Все места", "Гараж", "Склад 1", "Ангар", "Стеллаж А"]
        for z in viewModel.zones where !base.contains(z.name) {
            base.append(z.name)
        }
        return base
    }

    private var filteredItems: [GarageItem] {
        let filtered = viewModel.items.filter { item in
            let matchesZone = selectedZone == "Все места" ||
                item.zone.caseInsensitiveCompare(selectedZone) == .orderedSame ||
                item.shelfLocation.localizedCaseInsensitiveContains(selectedZone)
            let matchesSearch = searchQuery.trimmingCharacters(in: .whitespaces).isEmpty ||
                item.title.localizedCaseInsensitiveContains(searchQuery) ||
                item.qrCode.localizedCaseInsensitiveContains(searchQuery) ||
                item.barcode.localizedCaseInsensitiveContains(searchQuery) ||
                item.serialCode.localizedCaseInsensitiveContains(searchQuery) ||
                item.shelfLocation.localizedCaseInsensitiveContains(searchQuery)
            return matchesZone && matchesSearch
        }
        if sortByPriceDesc {
            return filtered.sorted { $0.price > $1.price }
        }
        return filtered
    }

    private var totalCapacity: Int64 {
        let sum = viewModel.zones.reduce(0) { $0 + $1.capacity }
        return sum > 0 ? sum : 185
    }

    private var freeSlots: Int64 {
        max(totalCapacity - Int64(viewModel.items.count), 0)
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 12) {
                // Header
                HStack(spacing: 4) {
                    Text("МОЙ СКЛАД")
                        .font(.system(size: 16, weight: .bold, design: .rounded))
                        .foregroundColor(GarageTheme.textPrimary)
                    Text(" | Всего: \(viewModel.items.count) товара • Свободно \(freeSlots) мест")
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(GarageTheme.textSecondary)
                        .lineLimit(1)
                }
                .padding(.top, 4)

                // Search bar + Sort button
                HStack(spacing: 8) {
                    HStack(spacing: 8) {
                        Image(systemName: "magnifyingglass")
                            .font(.system(size: 15))
                            .foregroundColor(GarageTheme.textSecondary)
                        TextField("Поиск по складу (название, QR, штрихкод, ID)...", text: $searchQuery)
                            .font(.system(size: 13))
                            .foregroundColor(GarageTheme.textPrimary)
                            .autocorrectionDisabled()
                    }
                    .padding(.horizontal, 12)
                    .frame(height: 46)
                    .background(GarageTheme.cardBg)
                    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .stroke(GarageTheme.outline, lineWidth: 1)
                    )

                    Button {
                        sortByPriceDesc.toggle()
                    } label: {
                        ZStack {
                            RoundedRectangle(cornerRadius: 12, style: .continuous)
                                .fill(sortByPriceDesc ? GarageTheme.orange.opacity(0.2) : GarageTheme.cardBg)
                                .frame(width: 46, height: 46)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                                        .stroke(sortByPriceDesc ? GarageTheme.orange : GarageTheme.outline, lineWidth: 1)
                                )
                            Image(systemName: "arrow.up.arrow.down")
                                .font(.system(size: 16, weight: .bold))
                                .foregroundColor(sortByPriceDesc ? GarageTheme.orange : GarageTheme.textSecondary)
                        }
                    }
                    .buttonStyle(.plain)
                }

                // Horizontal Zone Filter Chips
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(zoneFilters, id: \.self) { zone in
                            let isSelected = selectedZone == zone
                            Button {
                                selectedZone = zone
                            } label: {
                                Text(zone)
                                    .font(.system(size: 12, weight: isSelected ? .bold : .medium))
                                    .foregroundColor(isSelected ? .white : GarageTheme.textSecondary)
                                    .padding(.horizontal, 14)
                                    .padding(.vertical, 8)
                                    .background(isSelected ? GarageTheme.orange : GarageTheme.cardBg)
                                    .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 10, style: .continuous)
                                            .stroke(isSelected ? GarageTheme.orange : GarageTheme.outline, lineWidth: 1)
                                    )
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }

                // 3 Warehouse Action Cards
                HStack(spacing: 10) {
                    WarehouseActionCardIOS(
                        icon: "qrcode.viewfinder",
                        title: "Сканировать\nQR / штрихкод",
                        isHighlighted: true,
                        highlightColor: GarageTheme.electricBlue,
                        onClick: onOpenQrScanner
                    )
                    WarehouseActionCardIOS(
                        icon: "plus",
                        title: "Добавить\nтовар",
                        isHighlighted: false,
                        highlightColor: GarageTheme.orange,
                        onClick: onAddItem
                    )
                    WarehouseActionCardIOS(
                        icon: "checklist",
                        title: isInventoryAuditMode ? "Инвентаризация\n(Вкл)" : "Инвентаризация",
                        isHighlighted: isInventoryAuditMode,
                        highlightColor: GarageTheme.emeraldGreen,
                        onClick: { isInventoryAuditMode.toggle() }
                    )
                }

                if isInventoryAuditMode {
                    let verifiedCount = viewModel.items.filter(\.isVerifiedInInventory).count
                    HStack {
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Режим сверки остатков активен")
                                .font(.system(size: 13, weight: .bold, design: .rounded))
                                .foregroundColor(GarageTheme.emeraldGreen)
                            Text("Отмечайте галочкой товары, которые физически проверены на полке (\(verifiedCount) из \(viewModel.items.count))")
                                .font(.system(size: 11))
                                .foregroundColor(GarageTheme.textSecondary)
                        }
                        Spacer()
                        ProgressView(value: Double(verifiedCount) / Double(max(viewModel.items.count, 1)))
                            .progressViewStyle(.circular)
                            .tint(GarageTheme.emeraldGreen)
                    }
                    .padding(12)
                    .background(GarageTheme.emeraldGreen.opacity(0.14))
                    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .stroke(GarageTheme.emeraldGreen.opacity(0.45), lineWidth: 1)
                    )
                }

                // Detailed Item Cards
                ForEach(filteredItems) { item in
                    WarehouseDetailedItemCardIOS(
                        item: item,
                        isInventoryAuditMode: isInventoryAuditMode,
                        onCardClick: { onEditItem(item) },
                        onPhotoHintClick: { onOpenPhotoHint(item) },
                        onToggleVerified: { viewModel.toggleInventoryVerification(item) }
                    )
                }
            }
            .padding(.horizontal, 16)
            .padding(.top, 8)
            .padding(.bottom, 24)
        }
    }
}

private struct WarehouseActionCardIOS: View {
    let icon: String
    let title: String
    let isHighlighted: Bool
    let highlightColor: Color
    let onClick: () -> Void

    var body: some View {
        Button(action: onClick) {
            VStack(spacing: 6) {
                Image(systemName: icon)
                    .font(.system(size: 22, weight: .bold))
                    .foregroundColor(isHighlighted ? highlightColor : GarageTheme.textPrimary)

                Text(title)
                    .font(.system(size: 11, weight: .semibold, design: .rounded))
                    .foregroundColor(GarageTheme.textPrimary)
                    .multilineTextAlignment(.center)
                    .lineSpacing(1)
                    .lineLimit(2)
            }
            .frame(maxWidth: .infinity)
            .frame(height: 82)
            .padding(6)
            .background(isHighlighted ? highlightColor.opacity(0.14) : GarageTheme.cardBg)
            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .stroke(
                        isHighlighted ? highlightColor : GarageTheme.outline,
                        lineWidth: isHighlighted ? 1.5 : 1
                    )
            )
        }
        .buttonStyle(.plain)
    }
}

private struct WarehouseDetailedItemCardIOS: View {
    let item: GarageItem
    let isInventoryAuditMode: Bool
    let onCardClick: () -> Void
    let onPhotoHintClick: () -> Void
    let onToggleVerified: () -> Void

    private var statusInfo: (Color, String) {
        switch item.publicationStatus {
        case "published":
            return (GarageTheme.emeraldGreen, "Статус: Опубликовано везде")
        case "partial":
            return (GarageTheme.amber, "Статус: Опубликовано частично")
        default:
            return (GarageTheme.textSecondary, "Статус: Не опубликовано (Черновик)")
        }
    }

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            // Left column: 90pt thumbnail + 34pt shelf photo preview
            VStack(spacing: 6) {
                ItemThumbnailBox(
                    photoUri: item.photoUri,
                    title: item.title,
                    width: 90,
                    height: 82,
                    cornerRadius: 12
                )

                Button(action: onPhotoHintClick) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 8, style: .continuous)
                            .fill(Color(red: 29/255, green: 34/255, blue: 46/255))
                            .frame(width: 90, height: 34)
                            .overlay(
                                RoundedRectangle(cornerRadius: 8, style: .continuous)
                                    .stroke(GarageTheme.outline, lineWidth: 1)
                            )
                        Text("📷 Полка: \(item.zone)")
                            .font(.system(size: 10, weight: .semibold))
                            .foregroundColor(GarageTheme.textSecondary)
                            .lineLimit(1)
                            .padding(.horizontal, 4)
                    }
                }
                .buttonStyle(.plain)
            }

            // Right column: title, price, location, QR/barcode, PhotoHintChip, status + platform icons
            VStack(alignment: .leading, spacing: 5) {
                HStack(alignment: .top) {
                    Text(item.title)
                        .font(.system(size: 14, weight: .bold, design: .rounded))
                        .foregroundColor(GarageTheme.textPrimary)
                        .lineLimit(2)

                    Spacer()

                    if isInventoryAuditMode || item.isVerifiedInInventory {
                        Button(action: onToggleVerified) {
                            Image(systemName: item.isVerifiedInInventory ? "checkmark.circle.fill" : "circle")
                                .font(.system(size: 20))
                                .foregroundColor(item.isVerifiedInInventory ? GarageTheme.emeraldGreen : GarageTheme.textSecondary)
                        }
                        .buttonStyle(.plain)
                    }
                }

                HStack(alignment: .firstTextBaseline, spacing: 8) {
                    Text(formatRubles(item.price))
                        .font(.system(size: 15, weight: .heavy, design: .rounded))
                        .foregroundColor(GarageTheme.emeraldGreen)

                    if item.quantity > 1 {
                        Text("(\(item.quantity) \(item.unitLabel))")
                            .font(.system(size: 11))
                            .foregroundColor(GarageTheme.textSecondary)
                    }
                }

                HStack(alignment: .top, spacing: 4) {
                    Image(systemName: "mappin.and.ellipse")
                        .font(.system(size: 11))
                        .foregroundColor(GarageTheme.textSecondary)
                    Text("Место хранения: \(item.zone), \(item.shelfLocation)")
                        .font(.system(size: 11))
                        .foregroundColor(GarageTheme.textSecondary)
                        .lineLimit(2)
                }

                let codeDetails: String = {
                    var str = "QR: \(item.qrCode)"
                    if !item.barcode.isEmpty { str += " | Штрихкод: \(item.barcode)" }
                    if !item.serialCode.isEmpty { str += " | ID: \(item.serialCode)" }
                    return str
                }()

                Text(codeDetails)
                    .font(.system(size: 10.5))
                    .foregroundColor(GarageTheme.textSecondary)
                    .lineLimit(1)

                HStack {
                    PhotoHintChip(label: "Фото-подсказка", onClick: onPhotoHintClick)

                    Spacer()

                    if !item.barcode.isEmpty {
                        MiniBarcodeCanvas(code: item.barcode, width: 42, height: 18)
                    } else {
                        MiniQrCodeCanvas(code: item.qrCode, size: 22)
                    }
                }
                .padding(.top, 2)

                HStack {
                    HStack(spacing: 5) {
                        Circle()
                            .fill(statusInfo.0)
                            .frame(width: 7, height: 7)
                        Text(statusInfo.1)
                            .font(.system(size: 10.5, weight: .medium))
                            .foregroundColor(GarageTheme.textSecondary)
                            .lineLimit(1)
                    }

                    Spacer()

                    HStack(spacing: 4) {
                        ForEach(item.publishedPlatforms, id: \.self) { pKey in
                            PlatformBadgeIcon(
                                platformType: PlatformType.fromKey(pKey),
                                size: 18
                            )
                        }
                    }
                }
                .padding(.top, 2)
            }
        }
        .padding(12)
        .background(GarageTheme.cardBg)
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .stroke(GarageTheme.outline, lineWidth: 1)
        )
        .contentShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
        .onTapGesture(perform: onCardClick)
    }
}
