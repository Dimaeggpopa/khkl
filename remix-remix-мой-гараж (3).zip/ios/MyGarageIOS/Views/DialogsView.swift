import SwiftUI

struct DialogsView: View {
    @ObservedObject var viewModel: GarageViewModel
    let onOpenPhotoHint: (GarageItem) -> Void
    let onCreateDialog: () -> Void

    @State private var searchQuery: String = ""
    @State private var selectedPlatformFilter: String = "Все"
    @State private var activeChatDialogId: String? = nil

    private var unreadTotal: Int64 {
        viewModel.dialogs.reduce(0) { $0 + $1.unreadCount }
    }

    private var filteredDialogs: [BuyerDialog] {
        viewModel.dialogs.filter { d in
            let matchesPlatform: Bool = {
                switch selectedPlatformFilter {
                case "Авито": return d.platformKey == "avito"
                case "Юла": return d.platformKey == "youla"
                case "ВК Маркет": return d.platformKey == "vk"
                case "Яндекс": return d.platformKey == "yandex"
                default: return true
                }
            }()
            let matchesSearch = searchQuery.trimmingCharacters(in: .whitespaces).isEmpty ||
                d.buyerName.localizedCaseInsensitiveContains(searchQuery) ||
                d.itemTitle.localizedCaseInsensitiveContains(searchQuery) ||
                d.lastMessage.localizedCaseInsensitiveContains(searchQuery)
            return matchesPlatform && matchesSearch
        }
    }

    private var activeDialog: BuyerDialog? {
        guard let id = activeChatDialogId else { return nil }
        return viewModel.dialogs.first(where: { $0.id == id })
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 12) {
                // Header + "+ Диалог" button
                HStack {
                    HStack(spacing: 4) {
                        Text("ДИАЛОГИ")
                            .font(.system(size: 16, weight: .bold, design: .rounded))
                            .foregroundColor(GarageTheme.textPrimary)
                        Text(" | \(unreadTotal) непрочитанных")
                            .font(.system(size: 12, weight: .medium))
                            .foregroundColor(GarageTheme.textSecondary)
                    }

                    Spacer()

                    Button(action: onCreateDialog) {
                        HStack(spacing: 4) {
                            Image(systemName: "plus")
                                .font(.system(size: 13, weight: .bold))
                                .foregroundColor(GarageTheme.orange)
                            Text("Диалог")
                                .font(.system(size: 12, weight: .bold))
                                .foregroundColor(GarageTheme.textPrimary)
                        }
                        .padding(.horizontal, 10)
                        .padding(.vertical, 6)
                        .background(GarageTheme.cardBg)
                        .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                        .overlay(
                            RoundedRectangle(cornerRadius: 10, style: .continuous)
                                .stroke(GarageTheme.outline, lineWidth: 1)
                        )
                    }
                    .buttonStyle(.plain)
                }
                .padding(.top, 4)

                // Search bar
                HStack(spacing: 8) {
                    Image(systemName: "magnifyingglass")
                        .font(.system(size: 15))
                        .foregroundColor(GarageTheme.textSecondary)

                    TextField("Поиск по сообщениям (имя, товар, текст)...", text: $searchQuery)
                        .font(.system(size: 13))
                        .foregroundColor(GarageTheme.textPrimary)
                        .autocorrectionDisabled()
                }
                .padding(.horizontal, 12)
                .frame(height: 46)
                .background(GarageTheme.cardBg)
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                        .stroke(GarageTheme.outline, lineWidth: 1)
                )

                // Platform filter tabs
                let tabs = ["Все", "Авито", "Юла", "ВК Маркет", "Яндекс"]
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(tabs, id: \.self) { tab in
                            let isSelected = selectedPlatformFilter == tab
                            let countForTab: Int = {
                                switch tab {
                                case "Авито": return viewModel.dialogs.filter { $0.platformKey == "avito" }.count
                                case "Юла": return viewModel.dialogs.filter { $0.platformKey == "youla" }.count
                                case "ВК Маркет": return viewModel.dialogs.filter { $0.platformKey == "vk" }.count
                                case "Яндекс": return viewModel.dialogs.filter { $0.platformKey == "yandex" }.count
                                default: return viewModel.dialogs.count
                                }
                            }()

                            Button {
                                selectedPlatformFilter = tab
                            } label: {
                                Text(tab == "Все" ? "Все (\(countForTab))" : "\(tab) (\(countForTab))")
                                    .font(.system(size: 12, weight: isSelected ? .bold : .medium))
                                    .foregroundColor(isSelected ? .white : GarageTheme.textSecondary)
                                    .padding(.horizontal, 14)
                                    .padding(.vertical, 8)
                                    .background(isSelected ? GarageTheme.orange : GarageTheme.cardBg)
                                    .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 10, style: .continuous)
                                            .stroke(isSelected ? GarageTheme.orange : GarageTheme.outline, lineWidth: 1)
                                    )
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }

                // Dialog cards
                if filteredDialogs.isEmpty {
                    VStack(spacing: 6) {
                        Text("Диалогов пока нет")
                            .font(.system(size: 14, weight: .bold, design: .rounded))
                            .foregroundColor(GarageTheme.textPrimary)
                        Text("Нажмите «+ Диалог», чтобы добавить обращение покупателя с площадки")
                            .font(.system(size: 12))
                            .foregroundColor(GarageTheme.textSecondary)
                            .multilineTextAlignment(.center)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(22)
                    .background(GarageTheme.cardBg)
                    .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                } else {
                    ForEach(filteredDialogs) { dialog in
                        BuyerDialogRowCardIOS(
                            dialog: dialog,
                            onClick: {
                                viewModel.markDialogRead(dialog)
                                activeChatDialogId = dialog.id
                            }
                        )
                    }
                }
            }
            .padding(.horizontal, 16)
            .padding(.top, 8)
            .padding(.bottom, 24)
        }
        .sheet(isPresented: Binding(
            get: { activeDialog != nil },
            set: { if !$0 { activeChatDialogId = nil } }
        )) {
            if let dialog = activeDialog {
                CompactPhoneChatModalIOS(
                    dialog: dialog,
                    quickReplyTemplates: viewModel.quickReplyTemplates,
                    onDismiss: { activeChatDialogId = nil },
                    onSendMessage: { text in
                        viewModel.sendMessage(dialog: dialog, text: text, isFromMe: true)
                    },
                    onDeleteDialog: {
                        viewModel.deleteDialog(dialogId: dialog.id)
                        activeChatDialogId = nil
                    },
                    onOpenItemHint: {
                        if let matched = viewModel.items.first(where: {
                            $0.id == dialog.itemId ||
                            $0.qrCode == dialog.itemQrCode ||
                            $0.title == dialog.itemTitle
                        }) {
                            activeChatDialogId = nil
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) {
                                onOpenPhotoHint(matched)
                            }
                        } else {
                            let fallback = GarageItem(
                                id: dialog.itemId,
                                title: dialog.itemTitle,
                                price: dialog.itemPrice,
                                zone: "Гараж",
                                shelfLocation: dialog.itemShelfLocation,
                                qrCode: dialog.itemQrCode
                            )
                            activeChatDialogId = nil
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) {
                                onOpenPhotoHint(fallback)
                            }
                        }
                    }
                )
            }
        }
    }
}

private struct BuyerDialogRowCardIOS: View {
    let dialog: BuyerDialog
    let onClick: () -> Void

    var body: some View {
        let pType = PlatformType.fromKey(dialog.platformKey)

        Button(action: onClick) {
            HStack(spacing: 12) {
                // Avatar with top-right blue unread dot & bottom-right platform icon
                ZStack {
                    Circle()
                        .fill(
                            LinearGradient(
                                colors: [
                                    Color(red: 43/255, green: 51/255, blue: 70/255),
                                    Color(red: 28/255, green: 34/255, blue: 48/255)
                                ],
                                startPoint: .top,
                                endPoint: .bottom
                            )
                        )
                        .frame(width: 50, height: 50)
                        .overlay(
                            Circle()
                                .stroke(GarageTheme.outline, lineWidth: 1)
                        )

                    Text(String(dialog.buyerName.prefix(1)).uppercased())
                        .font(.system(size: 18, weight: .heavy, design: .rounded))
                        .foregroundColor(.white)

                    if dialog.unreadCount > 0 {
                        Circle()
                            .fill(GarageTheme.electricBlue)
                            .frame(width: 11, height: 11)
                            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topTrailing)
                    }

                    PlatformBadgeIcon(
                        platformType: pType,
                        size: 20,
                        showStatusDot: false
                    )
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottomTrailing)
                }
                .frame(width: 54, height: 54)

                // Middle text
                VStack(alignment: .leading, spacing: 3) {
                    HStack {
                        Text(dialog.buyerName)
                            .font(.system(size: 14, weight: .bold, design: .rounded))
                            .foregroundColor(GarageTheme.textPrimary)
                            .lineLimit(1)

                        Spacer()

                        Text(dialog.timeLabel)
                            .font(.system(size: 11))
                            .foregroundColor(GarageTheme.textSecondary)
                    }

                    Text(dialog.lastMessage)
                        .font(.system(size: 12.5, weight: dialog.unreadCount > 0 ? .semibold : .regular))
                        .foregroundColor(dialog.unreadCount > 0 ? GarageTheme.textPrimary : GarageTheme.textSecondary)
                        .lineLimit(2)
                        .multilineTextAlignment(.leading)

                    Text("\(pType.shortName) • \(dialog.itemTitle)")
                        .font(.system(size: 10.5, weight: .semibold))
                        .foregroundColor(GarageTheme.electricBlue)
                        .lineLimit(1)
                }

                // Right item thumbnail
                ItemThumbnailBox(
                    photoUri: dialog.itemPhotoUri,
                    title: dialog.itemTitle,
                    width: 54,
                    height: 54,
                    cornerRadius: 10
                )
            }
            .padding(12)
            .background(GarageTheme.cardBg)
            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .stroke(
                        dialog.unreadCount > 0 ? GarageTheme.electricBlue.opacity(0.6) : GarageTheme.outline,
                        lineWidth: 1
                    )
            )
        }
        .buttonStyle(.plain)
    }
}

private struct CompactPhoneChatModalIOS: View {
    let dialog: BuyerDialog
    let quickReplyTemplates: [String]
    let onDismiss: () -> Void
    let onSendMessage: (String) -> Void
    let onDeleteDialog: () -> Void
    let onOpenItemHint: () -> Void

    @State private var inputText: String = ""

    var body: some View {
        let pType = PlatformType.fromKey(dialog.platformKey)
        let messages = dialog.parsedMessages()

        ZStack {
            GarageTheme.surface
                .ignoresSafeArea()

            VStack(spacing: 10) {
                Capsule()
                    .fill(GarageTheme.textSecondary.opacity(0.35))
                    .frame(width: 38, height: 5)
                    .padding(.top, 10)

                // Top header
                HStack(spacing: 10) {
                    PlatformBadgeIcon(platformType: pType, size: 36)

                    VStack(alignment: .leading, spacing: 2) {
                        Text("\(dialog.buyerName) (\(pType.shortName))")
                            .font(.system(size: 14.5, weight: .bold, design: .rounded))
                            .foregroundColor(GarageTheme.textPrimary)
                        Text("\(dialog.itemTitle) • \(formatRubles(dialog.itemPrice))")
                            .font(.system(size: 11.5))
                            .foregroundColor(GarageTheme.emeraldGreen)
                            .lineLimit(1)
                    }

                    Spacer()

                    Button(action: onDeleteDialog) {
                        Image(systemName: "trash")
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(GarageTheme.dangerRed)
                            .padding(8)
                    }
                    .buttonStyle(.plain)

                    Button(action: onDismiss) {
                        Image(systemName: "xmark.circle.fill")
                            .font(.system(size: 22))
                            .foregroundColor(GarageTheme.textSecondary)
                    }
                    .buttonStyle(.plain)
                }

                // Orange shelf location & QR strip
                Button(action: onOpenItemHint) {
                    HStack {
                        HStack(spacing: 6) {
                            Image(systemName: "mappin.and.ellipse")
                                .font(.system(size: 14, weight: .bold))
                                .foregroundColor(GarageTheme.orange)
                            Text("Где лежит: \(dialog.itemShelfLocation) (QR: \(dialog.itemQrCode))")
                                .font(.system(size: 11, weight: .bold))
                                .foregroundColor(GarageTheme.textPrimary)
                                .lineLimit(1)
                        }

                        Spacer()

                        Text("Фото полки →")
                            .font(.system(size: 11, weight: .heavy))
                            .foregroundColor(GarageTheme.orange)
                    }
                    .padding(.horizontal, 10)
                    .padding(.vertical, 9)
                    .background(GarageTheme.orange.opacity(0.14))
                    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .stroke(GarageTheme.orange.opacity(0.45), lineWidth: 1)
                    )
                }
                .buttonStyle(.plain)

                // Chat bubbles
                ScrollView {
                    VStack(spacing: 8) {
                        ForEach(messages) { msg in
                            HStack {
                                if msg.isOutgoing { Spacer(minLength: 40) }

                                VStack(alignment: .leading, spacing: 3) {
                                    Text(msg.text)
                                        .font(.system(size: 13))
                                        .foregroundColor(.white)
                                    Text(msg.time)
                                        .font(.system(size: 9.5))
                                        .foregroundColor(.white.opacity(0.65))
                                }
                                .padding(.horizontal, 12)
                                .padding(.vertical, 8)
                                .background(
                                    msg.isOutgoing
                                        ? GarageTheme.electricBlue
                                        : Color(red: 36/255, green: 42/255, blue: 56/255)
                                )
                                .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))

                                if !msg.isOutgoing { Spacer(minLength: 40) }
                            }
                        }
                    }
                    .padding(.vertical, 6)
                }

                // Quick Reply Chips
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 6) {
                        ForEach(quickReplyTemplates, id: \.self) { template in
                            Button {
                                onSendMessage(template)
                            } label: {
                                Text(template)
                                    .font(.system(size: 11))
                                    .foregroundColor(GarageTheme.textPrimary)
                                    .lineLimit(1)
                                    .padding(.horizontal, 10)
                                    .padding(.vertical, 6)
                                    .background(Color(red: 32/255, green: 38/255, blue: 52/255))
                                    .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 10, style: .continuous)
                                            .stroke(GarageTheme.outline, lineWidth: 1)
                                    )
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }

                // Bottom input bar
                HStack(spacing: 8) {
                    TextField("Ответить покупателю...", text: $inputText)
                        .font(.system(size: 14))
                        .foregroundColor(GarageTheme.textPrimary)
                        .padding(.horizontal, 12)
                        .frame(height: 44)
                        .background(GarageTheme.cardBg)
                        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                        .overlay(
                            RoundedRectangle(cornerRadius: 14, style: .continuous)
                                .stroke(GarageTheme.outline, lineWidth: 1)
                        )

                    Button {
                        let trimmed = inputText.trimmingCharacters(in: .whitespacesAndNewlines)
                        guard !trimmed.isEmpty else { return }
                        onSendMessage(trimmed)
                        inputText = ""
                    } label: {
                        ZStack {
                            Circle()
                                .fill(GarageTheme.orange)
                                .frame(width: 44, height: 44)
                            Image(systemName: "paperplane.fill")
                                .font(.system(size: 17, weight: .bold))
                                .foregroundColor(.white)
                        }
                    }
                    .buttonStyle(.plain)
                }
                .padding(.bottom, 8)
            }
            .padding(.horizontal, 16)
        }
    }
}
