import SwiftUI

struct AuthView: View {
    let onSignedIn: (String, String) -> Void

    @State private var emailInput: String = "dimaegggpopa@gmail.com"
    @State private var isLoading = false

    var body: some View {
        ZStack {
            GarageTheme.background
                .ignoresSafeArea()

            VStack(spacing: 18) {
                Spacer(minLength: 8)

                VStack(spacing: 14) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 24, style: .continuous)
                            .fill(GarageTheme.cardBg)
                            .frame(width: 88, height: 88)
                            .overlay(
                                RoundedRectangle(cornerRadius: 24, style: .continuous)
                                    .stroke(GarageTheme.orange.opacity(0.55), lineWidth: 1.5)
                            )

                        GarageBrandLogo(size: 56)
                    }

                    Text("Мой гараж")
                        .font(.system(size: 28, weight: .heavy, design: .rounded))
                        .foregroundColor(GarageTheme.textPrimary)

                    Text("Умный склад, учёт по QR и штрихкодам, фото-подсказки полок и выгрузка в 1 клик на площадки")
                        .font(.system(size: 13.5, weight: .medium))
                        .foregroundColor(GarageTheme.textSecondary)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 8)

                    HStack(spacing: 16) {
                        ForEach(PlatformType.allCases) { platform in
                            VStack(spacing: 5) {
                                PlatformBadgeIcon(
                                    platformType: platform,
                                    size: 44,
                                    showStatusDot: true,
                                    isConnected: true
                                )
                                Text(platform.shortName)
                                    .font(.system(size: 11, weight: .medium))
                                    .foregroundColor(GarageTheme.textSecondary)
                            }
                        }
                    }
                    .padding(.top, 4)
                }

                VStack(spacing: 10) {
                    AuthFeatureRowIOS(
                        icon: "bolt.fill",
                        title: "Публикация в 1 клик",
                        subtitle: "Размещение сразу всех товаров на Авито, Юлу, ВК и Яндекс без сбоев"
                    )
                    AuthFeatureRowIOS(
                        icon: "qrcode.viewfinder",
                        title: "QR-коды, штрихкоды и фото-подсказки",
                        subtitle: "Мгновенный поиск нужной полки и фото места хранения в любой ситуации"
                    )
                    AuthFeatureRowIOS(
                        icon: "shippingbox.fill",
                        title: "Полностью бесплатно • Без подписок",
                        subtitle: "Все функции склада, инвентаризации и единых диалогов открыты сразу"
                    )
                }

                Spacer(minLength: 8)

                VStack(spacing: 10) {
                    HStack(spacing: 8) {
                        Image(systemName: "envelope.fill")
                            .foregroundColor(GarageTheme.textSecondary)
                        TextField("Ваш Google / Apple ID Email", text: $emailInput)
                            .foregroundColor(GarageTheme.textPrimary)
                            .keyboardType(.emailAddress)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                    }
                    .padding(12)
                    .background(GarageTheme.cardBg)
                    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .stroke(GarageTheme.outline, lineWidth: 1)
                    )

                    Button {
                        isLoading = true
                        let cleanEmail = emailInput.trimmingCharacters(in: .whitespacesAndNewlines)
                        let finalEmail = cleanEmail.isEmpty ? "dimaegggpopa@gmail.com" : cleanEmail
                        onSignedIn(finalEmail, "user_\(abs(finalEmail.hashValue))")
                    } label: {
                        HStack(spacing: 10) {
                            Image(systemName: "checkmark.shield.fill")
                                .font(.system(size: 18, weight: .bold))
                            Text("Войти через Google")
                                .font(.system(size: 16, weight: .bold, design: .rounded))
                        }
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .frame(height: 56)
                        .background(
                            LinearGradient(
                                colors: [GarageTheme.orange, GarageTheme.electricBlue],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                    }
                    .buttonStyle(.plain)
                    .disabled(isLoading)

                    Text("Облачная синхронизация вашего склада и привязанных площадок")
                        .font(.system(size: 11, weight: .medium))
                        .foregroundColor(GarageTheme.textSecondary)
                        .multilineTextAlignment(.center)
                }
            }
            .padding(.horizontal, 24)
            .padding(.vertical, 20)
        }
    }
}

private struct AuthFeatureRowIOS: View {
    let icon: String
    let title: String
    let subtitle: String

    var body: some View {
        HStack(spacing: 12) {
            ZStack {
                Circle()
                    .fill(GarageTheme.orange.opacity(0.16))
                    .frame(width: 40, height: 40)
                Image(systemName: icon)
                    .font(.system(size: 18, weight: .bold))
                    .foregroundColor(GarageTheme.orange)
            }
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.system(size: 14, weight: .bold, design: .rounded))
                    .foregroundColor(GarageTheme.textPrimary)
                Text(subtitle)
                    .font(.system(size: 12))
                    .foregroundColor(GarageTheme.textSecondary)
            }
            Spacer()
        }
        .padding(12)
        .background(GarageTheme.cardBg)
        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .stroke(GarageTheme.outline, lineWidth: 1)
        )
    }
}
