#!/usr/bin/env bash
set -euo pipefail

echo "=== Сборка Мой гараж для iPhone (iOS .ipa) ==="
cd "$(dirname "$0")"

if ! command -v xcodegen >/dev/null 2>&1; then
  echo "Установка XcodeGen..."
  brew install xcodegen
fi

echo "[1/3] Генерация Xcode-проекта MyGarageIOS.xcodeproj через XcodeGen..."
rm -rf MyGarageIOS.xcodeproj
xcodegen generate

# Принудительно устанавливаем objectVersion = 56 (совместимость с Xcode 15.x и Xcode 16.x на GitHub Actions)
sed -i.bak 's/objectVersion = 77;/objectVersion = 56;/g' MyGarageIOS.xcodeproj/project.pbxproj || true
sed -i.bak 's/objectVersion = 70;/objectVersion = 56;/g' MyGarageIOS.xcodeproj/project.pbxproj || true
rm -f MyGarageIOS.xcodeproj/project.pbxproj.bak

echo "[2/3] Компиляция iOS-приложения под iPhone (Release-iphoneos)..."
rm -rf ./build
xcodebuild build \
  -project MyGarageIOS.xcodeproj \
  -scheme MyGarageIOS \
  -configuration Release \
  -sdk iphoneos \
  -derivedDataPath ./build/DerivedData \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY="" \
  AD_HOC_CODE_SIGNING_ALLOWED=YES

APP_PATH=$(find ./build/DerivedData -name "MyGarageIOS.app" -type d | head -n 1)
if [ -z "$APP_PATH" ]; then
  echo "Ошибка: MyGarageIOS.app не найден после сборки"
  exit 1
fi

echo "[3/3] Упаковка Payload в MyGarageIOS.ipa..."
mkdir -p ./build/ipa/Payload
cp -R "$APP_PATH" ./build/ipa/Payload/MyGarageIOS.app
(cd ./build/ipa && zip -qr ../MyGarageIOS.ipa Payload)

echo "Готово! Файл для установки на iPhone создан: $(pwd)/build/MyGarageIOS.ipa"
ls -lh ./build/MyGarageIOS.ipa
