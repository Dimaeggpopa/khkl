import Foundation

final class GarageRepository {
    static let projectId = "gen-lang-client-0886661216"
    static let databaseId = "ai-studio-android-118a4e2a-5c69-4018-9cc3-1ff1d7dac084"

    private let defaults = UserDefaults.standard
    private let encoder = JSONEncoder()
    private let decoder = JSONDecoder()

    private func itemsKey(_ userId: String) -> String { "garage_items_\(userId)" }
    private func platformsKey(_ userId: String) -> String { "garage_platforms_\(userId)" }
    private func dialogsKey(_ userId: String) -> String { "garage_dialogs_\(userId)" }
    private func zonesKey(_ userId: String) -> String { "garage_zones_\(userId)" }

    func loadItems(userId: String) -> [GarageItem] {
        guard let data = defaults.data(forKey: itemsKey(userId)),
              let list = try? decoder.decode([GarageItem].self, from: data) else {
            let initial = Self.defaultItems(userId: userId)
            saveItemsList(initial, userId: userId)
            return initial
        }
        return list
    }

    func saveItemsList(_ list: [GarageItem], userId: String) {
        if let data = try? encoder.encode(list) {
            defaults.set(data, forKey: itemsKey(userId))
        }
    }

    func loadPlatforms(userId: String) -> [PlatformConnection] {
        if let data = defaults.data(forKey: platformsKey(userId)),
           let list = try? decoder.decode([PlatformConnection].self, from: data),
           !list.isEmpty {
            return list
        }
        let initial = PlatformType.allCases.map { type in
            PlatformConnection(
                id: type.rawValue,
                userId: userId,
                platformKey: type.rawValue,
                platformName: type.displayName,
                isConnected: true,
                isSelectedForUpload: true,
                accountIdentifier: "PRO-\(type.shortName.uppercased())",
                lastSyncStatus: "Подключено • Готово к выгрузке"
            )
        }
        savePlatformsList(initial, userId: userId)
        return initial
    }

    func savePlatformsList(_ list: [PlatformConnection], userId: String) {
        if let data = try? encoder.encode(list) {
            defaults.set(data, forKey: platformsKey(userId))
        }
    }

    func loadDialogs(userId: String) -> [BuyerDialog] {
        if let data = defaults.data(forKey: dialogsKey(userId)),
           let list = try? decoder.decode([BuyerDialog].self, from: data) {
            return list
        }
        let initial = Self.defaultDialogs(userId: userId)
        saveDialogsList(initial, userId: userId)
        return initial
    }

    func saveDialogsList(_ list: [BuyerDialog], userId: String) {
        if let data = try? encoder.encode(list) {
            defaults.set(data, forKey: dialogsKey(userId))
        }
    }

    func loadZones(userId: String) -> [StorageZone] {
        if let data = defaults.data(forKey: zonesKey(userId)),
           let list = try? decoder.decode([StorageZone].self, from: data) {
            return list
        }
        let initial = [
            StorageZone(userId: userId, name: "Гараж • Стеллаж А", capacity: 60, description: "Основной металлический стеллаж у входа"),
            StorageZone(userId: userId, name: "Бокс 2 • Инструменты", capacity: 40, description: "Полки с электроинструментом и запчастями")
        ]
        saveZonesList(initial, userId: userId)
        return initial
    }

    func saveZonesList(_ list: [StorageZone], userId: String) {
        if let data = try? encoder.encode(list) {
            defaults.set(data, forKey: zonesKey(userId))
        }
    }

    // MARK: - Generators & Defaults

    static func generateQrCode() -> String {
        let num = Int.random(in: 100...999)
        let roman = ["I", "II", "III", "IV", "V"].randomElement() ?? "I"
        return "#GAR-\(num)-\(roman)"
    }

    static func generateBarcode() -> String {
        let digits = (1...9).map { _ in String(Int.random(in: 0...9)) }.joined()
        return "4607\(digits)"
    }

    static func currentTimeFormatted() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        return formatter.string(from: Date())
    }

    static func defaultItems(userId: String) -> [GarageItem] {
        [
            GarageItem(
                id: "item_1",
                userId: userId,
                title: "Набор профессионального инструмента 150 предм.",
                description: "Полный комплект торцевых головок и трещоток в кейсе, состояние идеальное.",
                price: 8900,
                quantity: 2,
                unitLabel: "шт.",
                zone: "Гараж",
                shelfLocation: "Стеллаж А2, полка 2",
                qrCode: "#GAR-204-II",
                barcode: "4607184920115",
                serialCode: "SN-PRO-150",
                hintNote: "Синий пластиковый кейс справа от верстака на 2-й полке",
                publishedPlatforms: ["avito", "youla", "vk", "yandex"],
                publicationStatus: "published",
                isSelectedForPublish: true,
                viewsCount: 142,
                inquiriesCount: 5,
                isVerifiedInInventory: true
            ),
            GarageItem(
                id: "item_2",
                userId: userId,
                title: "Компрессор воздушный 50л (220В)",
                description: "Масляный компрессор для пневмоинструмента и покраски, шланг 10м в комплекте.",
                price: 14500,
                quantity: 1,
                unitLabel: "шт.",
                zone: "Бокс",
                shelfLocation: "Сектор В1, нижний ярус",
                qrCode: "#GAR-512-I",
                barcode: "4607992341092",
                serialCode: "KMP-50L",
                hintNote: "У дальнего правого угла под стеллажом В1",
                publishedPlatforms: ["avito", "vk"],
                publicationStatus: "partial",
                isSelectedForPublish: true,
                viewsCount: 84,
                inquiriesCount: 2,
                isVerifiedInInventory: true
            ),
            GarageItem(
                id: "item_3",
                userId: userId,
                title: "Комплект литых дисков R17 5x114.3",
                description: "Ровные, без сварки и трещин, упакованы в коробки.",
                price: 26000,
                quantity: 4,
                unitLabel: "диска",
                zone: "Склад",
                shelfLocation: "Стеллаж шин С3",
                qrCode: "#GAR-778-IV",
                barcode: "4607551209834",
                serialCode: "R17-5114",
                hintNote: "4 картонные коробки с жёлтой маркировкой на стойке С3",
                publishedPlatforms: ["avito", "youla", "yandex"],
                publicationStatus: "partial",
                isSelectedForPublish: true,
                viewsCount: 210,
                inquiriesCount: 7,
                isVerifiedInInventory: false
            )
        ]
    }

    static func defaultDialogs(userId: String) -> [BuyerDialog] {
        [
            BuyerDialog(
                id: "dlg_1",
                userId: userId,
                buyerName: "Дмитрий (Покупатель)",
                platformKey: "avito",
                itemId: "item_1",
                itemTitle: "Набор профессионального инструмента 150 предм.",
                itemPrice: 8900,
                itemShelfLocation: "Стеллаж А2, полка 2",
                itemQrCode: "#GAR-204-II",
                lastMessage: "Здравствуйте! Сегодня вечером можно подъехать забрать?",
                timeLabel: "14:20",
                unreadCount: 1,
                messagesLog: [
                    "BUYER|14:18|Здравствуйте! Все головки на месте в наборе?",
                    "ME|14:19|Добрый день! Да, проверил по QR на стеллаже А2 — полный комплект.",
                    "BUYER|14:20|Здравствуйте! Сегодня вечером можно подъехать забрать?"
                ]
            ),
            BuyerDialog(
                id: "dlg_2",
                userId: userId,
                buyerName: "Максим",
                platformKey: "vk",
                itemId: "item_3",
                itemTitle: "Комплект литых дисков R17 5x114.3",
                itemPrice: 26000,
                itemShelfLocation: "Стеллаж шин С3",
                itemQrCode: "#GAR-778-IV",
                lastMessage: "Отправите ТК в другой город?",
                timeLabel: "12:05",
                unreadCount: 0,
                messagesLog: [
                    "BUYER|12:05|Отправите ТК в другой город?"
                ]
            )
        ]
    }
}
