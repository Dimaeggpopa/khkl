import SwiftUI

@main
struct MyGarageApp: App {
    @AppStorage("garage_ios_signed_in") private var isSignedIn: Bool = false
    @AppStorage("garage_ios_user_email") private var userEmail: String = "dimaegggpopa@gmail.com"
    @AppStorage("garage_ios_user_id") private var userId: String = "ios_owner_1"

    var body: some Scene {
        WindowGroup {
            Group {
                if isSignedIn {
                    MainTabView(
                        userId: userId,
                        userEmail: userEmail,
                        onSignOut: {
                            isSignedIn = false
                        }
                    )
                } else {
                    AuthView(
                        onSignedIn: { email, uid in
                            userEmail = email
                            userId = uid
                            isSignedIn = true
                        }
                    )
                }
            }
            .preferredColorScheme(.dark)
        }
    }
}
