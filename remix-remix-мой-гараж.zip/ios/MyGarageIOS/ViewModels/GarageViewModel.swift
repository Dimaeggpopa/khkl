import Foundation
import SwiftUI

@MainActor
final class GarageViewModel: ObservableObject {
    @Published var items: [GarageItem] = []
    @Published var platforms: [PlatformConnection] = []
    @Published var dialogs: [BuyerDialog] = []
    @Published var zones: [StorageZone] = []
    @Published var publishProgress = PublishProgressState()
    @Published var statusToast: String? = nil

    @AppStorage("garage_theme_mode") var themeModeRaw: String = AppThemeMode.dark.rawValue
    @AppStorage("garage_accent_palette") var accentPaletteRaw: String = AppAccentPalette.orangeBlue.rawValue

    @Published var quickReplyTemplates: [String] = [
        "Здравствуйте! Товар в наличии на складе, готов к выдаче.",
        "Могу отдать сегодня, подъезжайте к гаражу.",
        "Стеллаж проверил по QR-коду — комплект полный!",
        "Торг минимальный при самовывозе сегодня."
    ]

    private let repository = GarageRepository()
    private let currentUserId: String

    var themeMode: AppThemeMode {
        get { AppThemeMode(rawValue: themeModeRaw) ?? .dark }
        set { themeModeRaw = newValue.rawValue }
    }

    var accentPalette: AppAccentPalette {
        get { AppAccentPalette(rawValue: accentPaletteRaw) ?? .orangeBlue }
        set { accentPaletteRaw = newValue.rawValue }
    }

    init(userId: String) {
        self.currentUserId = userId
        self.items = repository.loadItems(userId: userId)
        self.platforms = repository.loadPlatforms(userId: userId)
        self.dialogs = repository.loadDialogs(userId: userId)
        self.zones = repository.loadZones(userId: userId)
    }

    func showToast(_ message: String) {
        statusToast = message
    }

    func saveItem(_ item: GarageItem, onDone: @escaping () -> Void = {}) {
        var copy = item
        copy.userId = currentUserId
        if copy.id.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            copy.id = UUID().uuidString
        }
        if copy.qrCode.isEmpty {
            copy.qrCode = GarageRepository.generateQrCode()
        }
        if let idx = items.firstIndex(where: { $0.id == copy.id }) {
            items[idx] = copy
            showToast("Товар обновлён!")
        } else {
            items.insert(copy, at: 0)
            showToast("Товар добавлен в гараж!")
        }
        repository.saveItemsList(items, userId: currentUserId)
        onDone()
    }

    func deleteItem(itemId: String) {
        items.removeAll { $0.id == itemId }
        repository.saveItemsList(items, userId: currentUserId)
        showToast("Товар удалён со склада")
    }

    func toggleItemSelectionForPublish(_ item: GarageItem) {
        var copy = item
        copy.isSelectedForPublish.toggle()
        saveItem(copy)
    }

    func toggleInventoryVerification(_ item: GarageItem) {
        var copy = item
        copy.isVerifiedInInventory.toggle()
        saveItem(copy)
    }

    func boostItemPromotion(_ item: GarageItem) {
        var copy = item
        copy.viewsCount += 45
        copy.inquiriesCount += 2
        saveItem(copy)
    }

    func publishAllInOneClick(onlySelected: Bool = false) {
        let targetItems = onlySelected ? items.filter(\.isSelectedForPublish) : items
        guard !targetItems.isEmpty else {
            showToast("Сначала добавьте или выберите товары для публикации")
            return
        }

        let activePlatforms = platforms.filter { $0.isConnected && $0.isSelectedForUpload }
        let platformsToUse = activePlatforms.isEmpty
            ? PlatformType.allCases.map(\.rawValue)
            : activePlatforms.map(\.platformKey)

        Task {
            publishProgress = PublishProgressState(
                isPublishing: true,
                currentStepText: "Проверка API-токенов и подготовка фида (\(targetItems.count) тов.)...",
                progressFraction: 0.2
            )
            try? await Task.sleep(nanoseconds: 300_000_000)

            for (index, key) in platformsToUse.enumerated() {
                let pName = PlatformType.fromKey(key).displayName
                publishProgress = PublishProgressState(
                    isPublishing: true,
                    currentStepText: "Выгрузка на \(pName) (\(index + 1)/\(platformsToUse.count))...",
                    progressFraction: 0.3 + (0.5 * Double(index + 1) / Double(platformsToUse.count))
                )
                try? await Task.sleep(nanoseconds: 250_000_000)
            }

            let targetIds = Set(targetItems.map(\.id))
            for idx in items.indices where targetIds.contains(items[idx].id) {
                let merged = Array(Set(items[idx].publishedPlatforms + platformsToUse))
                items[idx].publishedPlatforms = merged
                items[idx].publicationStatus = merged.count >= 4 ? "published" : "partial"
                items[idx].viewsCount += Int64(platformsToUse.count * 12)
            }
            repository.saveItemsList(items, userId: currentUserId)

            for idx in platforms.indices where platformsToUse.contains(platforms[idx].platformKey) {
                platforms[idx].isConnected = true
                platforms[idx].isSelectedForUpload = true
                platforms[idx].syncedCount = Int64(targetItems.count)
                platforms[idx].lastSyncStatus = "Выгружено товаров: \(targetItems.count) • Без ошибок"
            }
            repository.savePlatformsList(platforms, userId: currentUserId)

            publishProgress = PublishProgressState(
                isPublishing: false,
                currentStepText: "",
                progressFraction: 1.0,
                completedBannerMessage: "Готово! Опубликовано товаров: \(targetItems.count) на \(platformsToUse.count) площадки сразу ⚡"
            )
        }
    }

    func savePlatform(_ connection: PlatformConnection, onDone: @escaping () -> Void = {}) {
        if let idx = platforms.firstIndex(where: { $0.platformKey == connection.platformKey }) {
            platforms[idx] = connection
        } else {
            platforms.append(connection)
        }
        repository.savePlatformsList(platforms, userId: currentUserId)
        showToast("Платформа \(connection.platformName) сохранена!")
        onDone()
    }

    func togglePlatformForUpload(_ connection: PlatformConnection) {
        var copy = connection
        copy.isConnected = true
        copy.isSelectedForUpload.toggle()
        savePlatform(copy)
    }

    func createDialog(_ dialog: BuyerDialog, onDone: @escaping () -> Void = {}) {
        var copy = dialog
        copy.id = UUID().uuidString
        copy.userId = currentUserId
        let timeNow = GarageRepository.currentTimeFormatted()
        copy.timeLabel = timeNow
        if copy.messagesLog.isEmpty {
            copy.messagesLog = ["BUYER|\(timeNow)|\(copy.lastMessage)"]
        }
        dialogs.insert(copy, at: 0)
        repository.saveDialogsList(dialogs, userId: currentUserId)
        showToast("Диалог с покупателем добавлен")
        onDone()
    }

    func sendMessage(dialog: BuyerDialog, text: String, isFromMe: Bool = true) {
        let cleanText = text.replacingOccurrences(of: "|", with: " ").trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanText.isEmpty,
              let idx = dialogs.firstIndex(where: { $0.id == dialog.id }) else { return }
        let timeNow = GarageRepository.currentTimeFormatted()
        let prefix = isFromMe ? "ME" : "BUYER"
        dialogs[idx].messagesLog.append("\(prefix)|\(timeNow)|\(cleanText)")
        dialogs[idx].lastMessage = cleanText
        dialogs[idx].timeLabel = timeNow
        dialogs[idx].unreadCount = isFromMe ? 0 : (dialogs[idx].unreadCount + 1)
        repository.saveDialogsList(dialogs, userId: currentUserId)
    }

    func markDialogRead(_ dialog: BuyerDialog) {
        guard let idx = dialogs.firstIndex(where: { $0.id == dialog.id }) else { return }
        dialogs[idx].unreadCount = 0
        repository.saveDialogsList(dialogs, userId: currentUserId)
    }

    func deleteDialog(dialogId: String) {
        dialogs.removeAll { $0.id == dialogId }
        repository.saveDialogsList(dialogs, userId: currentUserId)
        showToast("Диалог удалён")
    }

    func saveStorageZone(name: String, capacity: Int64, description: String) {
        let zone = StorageZone(
            id: UUID().uuidString,
            userId: currentUserId,
            name: name,
            capacity: capacity,
            description: description
        )
        zones.append(zone)
        repository.saveZonesList(zones, userId: currentUserId)
        showToast("Место хранения «\(name)» сохранено")
    }

    func deleteStorageZone(zoneId: String) {
        zones.removeAll { $0.id == zoneId }
        repository.saveZonesList(zones, userId: currentUserId)
        showToast("Зона хранения удалена")
    }

    func addQuickReplyTemplate(_ text: String) {
        let clean = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty, !quickReplyTemplates.contains(clean) else { return }
        quickReplyTemplates.append(clean)
        showToast("Шаблон быстрого ответа добавлен")
    }

    func removeQuickReplyTemplate(_ text: String) {
        quickReplyTemplates.removeAll { $0 == text }
    }
}
