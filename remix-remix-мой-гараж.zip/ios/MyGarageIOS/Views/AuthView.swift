import SwiftUI

struct AuthView: View {
    let onSignedIn: (String, String) -> Void

    @State private var emailInput: String = "dimaegggpopa@gmail.com"
    @State private var isLoading = false

    var body: some View {
        ZStack {
            Color(red: 0.05, green: 0.06, blue: 0.09)
                .ignoresSafeArea()

            VStack(spacing: 22) {
                Spacer(minLength: 10)

                VStack(spacing: 14) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 24, style: .continuous)
                            .fill(Color(red: 0.11, green: 0.13, blue: 0.18))
                            .frame(width: 88, height: 88)
                            .overlay(
                                RoundedRectangle(cornerRadius: 24, style: .continuous)
                                    .stroke(Color.orange.opacity(0.6), lineWidth: 1.5)
                            )

                        Image(systemName: "shippingbox.and.arrow.backward.fill")
                            .font(.system(size: 38, weight: .bold))
                            .foregroundStyle(
                                LinearGradient(
                                    colors: [.orange, .blue],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                )
                            )
                    }

                    Text("Мой гараж")
                        .font(.system(size: 30, weight: .heavy, design: .rounded))
                        .foregroundColor(.white)

                    Text("Нативная версия для iPhone (iOS): умный склад по QR и штрихкодам, фото-подсказки полок и выгрузка в 1 клик на Авито, Юлу, ВК и Яндекс")
                        .font(.subheadline)
                        .foregroundColor(.gray)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 8)

                    HStack(spacing: 18) {
                        ForEach(PlatformType.allCases) { platform in
                            VStack(spacing: 6) {
                                Circle()
                                    .fill(platform.brandColor.opacity(0.2))
                                    .frame(width: 44, height: 44)
                                    .overlay(
                                        Text(String(platform.shortName.prefix(2)).uppercased())
                                            .font(.caption.bold())
                                            .foregroundColor(platform.brandColor)
                                    )
                                Text(platform.shortName)
                                    .font(.caption2)
                                    .foregroundColor(.secondary)
                            }
                        }
                    }
                    .padding(.top, 4)
                }

                VStack(spacing: 10) {
                    FeatureRowIOS(
                        icon: "bolt.fill",
                        title: "Публикация в 1 клик",
                        subtitle: "Размещение сразу всех товаров на Авито, Юлу, ВК и Яндекс без сбоев"
                    )
                    FeatureRowIOS(
                        icon: "qrcode.viewfinder",
                        title: "QR-коды, штрихкоды и фото-подсказки",
                        subtitle: "Мгновенный поиск нужной полки и фото места хранения с камеры iPhone"
                    )
                    FeatureRowIOS(
                        icon: "checkmark.seal.fill",
                        title: "Полностью бесплатно • Без подписок",
                        subtitle: "Все функции склада, инвентаризации и единых диалогов открыты сразу"
                    )
                }

                Spacer()

                VStack(spacing: 10) {
                    TextField("Ваш Google / Apple Email", text: $emailInput)
                        .textFieldStyle(.roundedBorder)
                        .keyboardType(.emailAddress)
                        .textInputAutocapitalization(.never)

                    Button {
                        isLoading = true
                        let cleanEmail = emailInput.trimmingCharacters(in: .whitespacesAndNewlines)
                        let finalEmail = cleanEmail.isEmpty ? "user@icloud.com" : cleanEmail
                        onSignedIn(finalEmail, "user_\(abs(finalEmail.hashValue))")
                    } label: {
                        HStack(spacing: 10) {
                            Image(systemName: "person.badge.shield.checkmark.fill")
                            Text("Войти в Мой гараж (iOS)")
                                .fontWeight(.bold)
                        }
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .frame(height: 54)
                        .background(
                            LinearGradient(
                                colors: [Color.orange, Color.blue],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                    }
                    .disabled(isLoading)

                    Text("Работает на любом iPhone (AltStore / Sideloadly / Xcode) без ограничений")
                        .font(.caption2)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                }
            }
            .padding(24)
        }
    }
}

private struct FeatureRowIOS: View {
    let icon: String
    let title: String
    let subtitle: String

    var body: some View {
        HStack(spacing: 12) {
            ZStack {
                Circle()
                    .fill(Color.orange.opacity(0.18))
                    .frame(width: 40, height: 40)
                Image(systemName: icon)
                    .foregroundColor(.orange)
            }
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.subheadline.bold())
                    .foregroundColor(.white)
                Text(subtitle)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            Spacer()
        }
        .padding(12)
        .background(Color(red: 0.11, green: 0.13, blue: 0.18))
        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
    }
}
